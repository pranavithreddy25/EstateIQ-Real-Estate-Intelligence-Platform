import os
import sys
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, 'data', 'demo', 'properties.csv')
MODEL_DIR = os.path.join(BASE_DIR, 'app', 'ml')
MODEL_PATH = os.path.join(MODEL_DIR, 'model.joblib')

def train():
    print("[INFO] Training EstateIQ ML Property Price Predictor Model...")
    if not os.path.exists(DATA_PATH):
        print(f"[ERROR] Error: {DATA_PATH} not found. Run generate_dataset.py first.")
        return

    df = pd.read_csv(DATA_PATH)
    
    # Feature matrix
    X = df[['locality', 'property_type', 'area_sqft', 'bedrooms', 'bathrooms', 'age_years']]
    y = df['price']

    # Preprocessing pipeline
    categorical_features = ['locality', 'property_type']
    numerical_features = ['area_sqft', 'bedrooms', 'bathrooms', 'age_years']

    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
            ('num', 'passthrough', numerical_features)
        ]
    )

    model_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
    ])

    model_pipeline.fit(X, y)

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model_pipeline, MODEL_PATH)

    print(f"[SUCCESS] ML Model successfully trained & saved to {MODEL_PATH}")

if __name__ == '__main__':
    train()
