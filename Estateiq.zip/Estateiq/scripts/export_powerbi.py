import os
import sys
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app import create_app
from app.extensions import db
from app.models import Property, Location, PriceHistory, Lead

def export():
    app = create_app('development')
    with app.app_context():
        export_dir = os.path.join(BASE_DIR, 'data', 'exports')
        os.makedirs(export_dir, exist_ok=True)
        print("[INFO] Exporting EstateIQ Power BI CSV Datasets (Telangana Statewide Hierarchy & Agri Analytics)...")

        # 1. Properties Dataset (Residential + Agricultural)
        props = Property.query.all()
        props_data = []
        for p in props:
            props_data.append({
                'property_id': p.id,
                'title': p.title,
                'property_type': p.property_type,
                'is_agricultural': p.is_agricultural,
                'purpose': p.purpose,
                'status': p.status,
                'locality': p.location_rel.name if p.location_rel else '',
                'district': p.location_rel.district if p.location_rel else 'Hyderabad',
                'mandal': p.location_rel.mandal if p.location_rel else '',
                'state': p.location_rel.state if p.location_rel else 'Telangana',
                'latitude': p.latitude,
                'longitude': p.longitude,
                'price_inr': p.price,
                'area_sqft': p.area_sqft,
                'price_per_sqft': p.price_per_sqft,
                'bedrooms': p.bedrooms,
                'bathrooms': p.bathrooms,
                'land_area_acres': p.land_area_acres,
                'land_area_guntas': p.land_area_guntas,
                'price_per_acre': p.price_per_acre,
                'soil_type': p.soil_type,
                'irrigation_source': p.irrigation_source,
                'crop_type': p.crop_type,
                'road_access': p.road_access,
                'est_monthly_rent': p.est_monthly_rent,
                'gross_rental_yield_pct': p.gross_rental_yield,
                'investment_score': p.investment_score,
                'agricultural_investment_score': p.agricultural_investment_score,
                'is_verified': p.is_verified,
                'is_featured': p.is_featured,
                'views_count': p.views_count,
                'leads_count': p.leads_count,
                'created_at': p.created_at
            })
        pd.DataFrame(props_data).to_csv(os.path.join(export_dir, 'properties_export.csv'), index=False)

        # 2. Locations Dataset (Full Telangana Hierarchy)
        locs = Location.query.all()
        locs_data = [l.to_dict() for l in locs]
        pd.DataFrame(locs_data).to_csv(os.path.join(export_dir, 'locations_export.csv'), index=False)

        # 3. Price History Dataset
        history = PriceHistory.query.all()
        hist_data = []
        for h in history:
            hist_data.append({
                'id': h.id,
                'location_id': h.location_id,
                'locality_name': h.location_rel.name if h.location_rel else '',
                'district': h.location_rel.district if h.location_rel else 'Hyderabad',
                'mandal': h.location_rel.mandal if h.location_rel else '',
                'year': h.year,
                'avg_price_per_sqft': h.avg_price_per_sqft,
                'avg_price_per_acre': h.avg_price_per_acre,
                'avg_monthly_rent': h.avg_monthly_rent
            })
        pd.DataFrame(hist_data).to_csv(os.path.join(export_dir, 'price_history_export.csv'), index=False)

        # 4. Leads Dataset
        leads = Lead.query.all()
        leads_data = []
        for ld in leads:
            leads_data.append({
                'lead_id': ld.id,
                'property_id': ld.property_id,
                'sender_name': ld.sender_name,
                'status': ld.status,
                'preferred_contact_time': ld.preferred_contact_time,
                'created_at': ld.created_at
            })
        pd.DataFrame(leads_data).to_csv(os.path.join(export_dir, 'leads_export.csv'), index=False)

        print(f"[SUCCESS] Power BI CSV Datasets successfully saved to {export_dir}")

if __name__ == '__main__':
    export()
