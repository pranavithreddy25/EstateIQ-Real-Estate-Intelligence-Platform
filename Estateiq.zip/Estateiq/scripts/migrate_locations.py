"""
Migration script: Normalizes existing location & property records to the 6-level Telangana administrative hierarchy.
Run: python scripts/migrate_locations.py
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from app.extensions import db
from app.models import Location, Property, AgriculturalDetails

# Known mapping of popular Hyderabad micro-markets to official Telangana Administrative Hierarchy
MICRO_MARKET_MAP = {
    "Kokapet": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500075", "avg_acre": 120000000},
    "Narsingi": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500075", "avg_acre": 95000000},
    "Tellapur": {"district": "Sangareddy", "mandal": "Shankarpally", "town_city": "Hyderabad", "pincode": "502032", "avg_acre": 75000000},
    "Gachibowli": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500032", "avg_acre": 150000000},
    "Hitec City": {"district": "Hyderabad", "mandal": "Khairatabad", "town_city": "Hyderabad", "pincode": "500081", "avg_acre": 180000000},
    "Jubilee Hills": {"district": "Hyderabad", "mandal": "Khairatabad", "town_city": "Hyderabad", "pincode": "500033", "avg_acre": 250000000},
    "Kondapur": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500084", "avg_acre": 110000000},
    "Manikonda": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500089", "avg_acre": 80000000},
    "Bachupally": {"district": "Medchal-Malkajgiri", "mandal": "Quthbullapur", "town_city": "Hyderabad", "pincode": "500090", "avg_acre": 55000000},
    "Madhapur": {"district": "Hyderabad", "mandal": "Khairatabad", "town_city": "Hyderabad", "pincode": "500081", "avg_acre": 160000000},
    "Financial District": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500075", "avg_acre": 160000000},
    "Puppalaguda": {"district": "Rangareddy", "mandal": "Gandipet", "town_city": "Hyderabad", "pincode": "500089", "avg_acre": 90000000},
    "Miyapur": {"district": "Medchal-Malkajgiri", "mandal": "Quthbullapur", "town_city": "Hyderabad", "pincode": "500049", "avg_acre": 60000000},
    "Kukatpally": {"district": "Medchal-Malkajgiri", "mandal": "Quthbullapur", "town_city": "Hyderabad", "pincode": "500072", "avg_acre": 90000000},
    "Kompally": {"district": "Medchal-Malkajgiri", "mandal": "Medchal", "town_city": "Hyderabad", "pincode": "500100", "avg_acre": 45000000},
    "Shadnagar": {"district": "Mahabubnagar", "mandal": "Shadnagar", "town_city": "Shadnagar", "pincode": "509216", "avg_acre": 18000000},
    "Shamshabad": {"district": "Rangareddy", "mandal": "Rajendranagar", "town_city": "Hyderabad", "pincode": "501218", "avg_acre": 35000000},
    "Patancheru": {"district": "Sangareddy", "mandal": "Patancheru", "town_city": "Hyderabad", "pincode": "502319", "avg_acre": 40000000},
    "Sangareddy Town": {"district": "Sangareddy", "mandal": "Sangareddy", "town_city": "Sangareddy", "pincode": "502001", "avg_acre": 25000000},
    "Siddipet Town": {"district": "Siddipet", "mandal": "Siddipet", "town_city": "Siddipet", "pincode": "502103", "avg_acre": 15000000},
    "Gajwel": {"district": "Siddipet", "mandal": "Gajwel", "town_city": "Gajwel", "pincode": "502278", "avg_acre": 20000000},
    "Vikarabad Town": {"district": "Vikarabad", "mandal": "Vikarabad", "town_city": "Vikarabad", "pincode": "501101", "avg_acre": 12000000},
    "Bhongir": {"district": "Yadadri Bhuvanagiri", "mandal": "Bhongir", "town_city": "Bhongir", "pincode": "508116", "avg_acre": 22000000},
    "Yadadri": {"district": "Yadadri Bhuvanagiri", "mandal": "Yadadri", "town_city": "Yadagirigutta", "pincode": "508115", "avg_acre": 28000000},
    "Warangal City": {"district": "Hanamkonda", "mandal": "Warangal", "town_city": "Warangal", "pincode": "506002", "avg_acre": 35000000},
    "Kazipet": {"district": "Hanamkonda", "mandal": "Hanamkonda", "town_city": "Warangal", "pincode": "506003", "avg_acre": 30000000},
    "Karimnagar City": {"district": "Karimnagar", "mandal": "Karimnagar", "town_city": "Karimnagar", "pincode": "505001", "avg_acre": 30000000},
    "Nizamabad City": {"district": "Nizamabad", "mandal": "Nizamabad Rural", "town_city": "Nizamabad", "pincode": "503001", "avg_acre": 22000000},
    "Khammam City": {"district": "Khammam", "mandal": "Khammam", "town_city": "Khammam", "pincode": "507001", "avg_acre": 25000000},
    "Nalgonda Town": {"district": "Nalgonda", "mandal": "Nalgonda", "town_city": "Nalgonda", "pincode": "508001", "avg_acre": 18000000},
}


def migrate():
    app = create_app('development')
    with app.app_context():
        print("=" * 60)
        print("  EstateIQ — Telangana Administrative Hierarchy Migration")
        print("=" * 60)

        # 1. Update existing Location records with standard hierarchy fields
        locations = Location.query.all()
        updated_locs = 0

        for loc in locations:
            matched = MICRO_MARKET_MAP.get(loc.name)
            if matched:
                loc.district = matched["district"]
                loc.mandal = matched["mandal"]
                loc.town_city = matched["town_city"]
                loc.locality_village = loc.name
                loc.location_type = "locality"
                loc.state = "Telangana"
                if not loc.pincode:
                    loc.pincode = matched["pincode"]
                if not loc.avg_price_per_acre or loc.avg_price_per_acre == 0:
                    loc.avg_price_per_acre = matched["avg_acre"]
                updated_locs += 1
            else:
                # If mandal is not set, default town/locality to name
                if not loc.locality_village:
                    loc.locality_village = loc.name
                if not loc.state:
                    loc.state = "Telangana"
                if not loc.location_type:
                    loc.location_type = "locality"

        db.session.commit()
        print(f"✓ Updated hierarchy metadata for {updated_locs} locations.")

        # 2. Normalize and verify Properties
        props = Property.query.all()
        updated_props = 0

        for p in props:
            loc = p.location_rel
            if loc:
                # Synchronize coordinates if missing
                if not p.latitude or not p.longitude:
                    p.latitude = loc.latitude
                    p.longitude = loc.longitude

                # Synchronize agricultural data
                if p.is_agricultural:
                    if p.land_area_acres and p.land_area_acres > 0:
                        if not p.land_area_guntas:
                            p.land_area_guntas = round(p.land_area_acres * 40.0, 2)
                        if not p.price_per_acre or p.price_per_acre == 0:
                            p.price_per_acre = round(p.price / p.land_area_acres, 2)

                    # Ensure AgriculturalDetails record exists
                    if not p.agricultural_details:
                        details = AgriculturalDetails(
                            property_id=p.id,
                            acres=p.land_area_acres or (p.area_sqft / 43560.0),
                            guntas=p.land_area_guntas or ((p.area_sqft / 43560.0) * 40.0),
                            cents=round((p.land_area_acres or (p.area_sqft / 43560.0)) * 100.0, 2),
                            total_sqft=p.area_sqft,
                            survey_number=p.survey_number or f"Sy. No. {p.id * 17 + 3}",
                            land_type=p.land_type or "Agricultural Patta",
                            irrigation_source=p.irrigation_source or "Borewell",
                            road_access=p.road_access or "BT Road",
                            soil_type=p.soil_type or "Red Soil",
                            crop_type=p.crop_type or "Paddy / Cotton",
                            electricity_available=True if p.electricity_available is None else p.electricity_available,
                            fencing_available=False if p.fencing_available is None else p.fencing_available,
                            farmhouse_available=False if p.farmhouse_available is None else p.farmhouse_available,
                            expected_annual_crop_income=p.expected_annual_crop_income or round(p.price * 0.04),
                            agricultural_investment_score=p.agricultural_investment_score or p.investment_score,
                        )
                        db.session.add(details)
                updated_props += 1

        db.session.commit()
        print(f"✓ Verified and normalized {updated_props} properties.")
        print("✓ Migration successfully completed!")
        print("=" * 60)


if __name__ == '__main__':
    migrate()
