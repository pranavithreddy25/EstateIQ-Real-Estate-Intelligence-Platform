import os
import json
import random
import pandas as pd
from datetime import datetime

# Setup directories
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'demo')
os.makedirs(DATA_DIR, exist_ok=True)

# Comprehensive Locality Master Dataset for Telangana (Major Hubs & Districts)
LOCALITIES = [
    # Top Residential Corridors
    {
        "name": "Kokapet",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Gandipet",
        "town_city": "Hyderabad",
        "locality_village": "Kokapet",
        "pincode": "500075",
        "latitude": 17.3850,
        "longitude": 78.3262,
        "avg_price_per_sqft": 7800,
        "avg_price_per_acre": 120000000,
        "avg_monthly_rent": 38000,
        "avg_rental_yield": 5.4,
        "annual_appreciation_rate": 8.5,
        "rental_demand_score": 92,
        "location_quality_score": 94,
        "growth_potential_score": 96,
        "total_inventory": 4500,
        "description": "Hyderabad's premier luxury high-rise expansion corridor with direct ORR connectivity and top IT hub access.",
        "highlights": ["Golden Mile SEZ", "ORR Junction", "International Schools", "High Rise Towers"]
    },
    {
        "name": "Narsingi",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Gandipet",
        "town_city": "Hyderabad",
        "pincode": "500075",
        "latitude": 17.3820,
        "longitude": 78.3580,
        "avg_price_per_sqft": 7100,
        "avg_price_per_acre": 95000000,
        "avg_monthly_rent": 33000,
        "avg_rental_yield": 5.2,
        "annual_appreciation_rate": 7.8,
        "rental_demand_score": 88,
        "location_quality_score": 89,
        "growth_potential_score": 90,
        "total_inventory": 3800,
        "description": "Rapidly appreciating residential zone connecting Financial District and Mehdipatnam.",
        "highlights": ["ORR Exit 1", "Proximity to Gachibowli", "Gated Communities"]
    },
    {
        "name": "Tellapur",
        "state": "Telangana",
        "district": "Sangareddy",
        "mandal": "Shankarpally",
        "town_city": "Hyderabad",
        "pincode": "502032",
        "latitude": 17.4520,
        "longitude": 78.2830,
        "avg_price_per_sqft": 6500,
        "avg_price_per_acre": 75000000,
        "avg_monthly_rent": 30000,
        "avg_rental_yield": 5.0,
        "annual_appreciation_rate": 8.2,
        "rental_demand_score": 85,
        "location_quality_score": 87,
        "growth_potential_score": 92,
        "total_inventory": 5200,
        "description": "Green mega-township cluster favoured by software engineers for large integrated gated societies.",
        "highlights": ["Integrated Townships", "Citizen Hospital", "Future Metro Phase 2"]
    },
    {
        "name": "Gachibowli",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Gandipet",
        "town_city": "Hyderabad",
        "pincode": "500032",
        "latitude": 17.4401,
        "longitude": 78.3489,
        "avg_price_per_sqft": 9200,
        "avg_price_per_acre": 150000000,
        "avg_monthly_rent": 45000,
        "avg_rental_yield": 4.8,
        "annual_appreciation_rate": 6.5,
        "rental_demand_score": 95,
        "location_quality_score": 96,
        "growth_potential_score": 85,
        "total_inventory": 6100,
        "description": "Established IT headquarters hub housing Microsoft, Google, Amazon and IIIT Hyderabad.",
        "highlights": ["Financial District", "Outdoor Sports Complex", "Bio-Diversity Park"]
    },
    {
        "name": "Hitec City",
        "state": "Telangana",
        "district": "Hyderabad",
        "mandal": "Khairatabad",
        "town_city": "Hyderabad",
        "pincode": "500081",
        "latitude": 17.4435,
        "longitude": 78.3772,
        "avg_price_per_sqft": 10500,
        "avg_price_per_acre": 180000000,
        "avg_monthly_rent": 52000,
        "avg_rental_yield": 4.6,
        "annual_appreciation_rate": 6.0,
        "rental_demand_score": 98,
        "location_quality_score": 98,
        "growth_potential_score": 80,
        "total_inventory": 4200,
        "description": "The economic heart of modern Cyberabad with blue-chip office parks and vibrant nightlife.",
        "highlights": ["Cyber Towers", "Mindspace IT Park", "Inorbit Mall", "Metro Terminal"]
    },
    {
        "name": "Jubilee Hills",
        "state": "Telangana",
        "district": "Hyderabad",
        "mandal": "Khairatabad",
        "town_city": "Hyderabad",
        "pincode": "500033",
        "latitude": 17.4319,
        "longitude": 78.4071,
        "avg_price_per_sqft": 16500,
        "avg_price_per_acre": 250000000,
        "avg_monthly_rent": 95000,
        "avg_rental_yield": 3.8,
        "annual_appreciation_rate": 5.5,
        "rental_demand_score": 84,
        "location_quality_score": 99,
        "growth_potential_score": 75,
        "total_inventory": 1800,
        "description": "Ultra-luxury residential enclave home to industrial titans, film celebrities and diplomats.",
        "highlights": ["KBR National Park", "Film Nagar", "High-End Dining", "Exclusive Clubbing"]
    },
    {
        "name": "Kondapur",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Gandipet",
        "town_city": "Hyderabad",
        "pincode": "500084",
        "latitude": 17.4622,
        "longitude": 78.3568,
        "avg_price_per_sqft": 8100,
        "avg_price_per_acre": 110000000,
        "avg_monthly_rent": 36000,
        "avg_rental_yield": 5.1,
        "annual_appreciation_rate": 7.0,
        "rental_demand_score": 91,
        "location_quality_score": 90,
        "growth_potential_score": 86,
        "total_inventory": 4900,
        "description": "Extremely active rental market nestled right between Hitec City and Botanical Gardens.",
        "highlights": ["Botanical Garden", "Sarath City Capital Mall", "Heritage Hospital"]
    },
    {
        "name": "Manikonda",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Gandipet",
        "town_city": "Hyderabad",
        "pincode": "500089",
        "latitude": 17.3995,
        "longitude": 78.3758,
        "avg_price_per_sqft": 6200,
        "avg_price_per_acre": 80000000,
        "avg_monthly_rent": 27000,
        "avg_rental_yield": 5.2,
        "annual_appreciation_rate": 6.8,
        "rental_demand_score": 86,
        "location_quality_score": 82,
        "growth_potential_score": 84,
        "total_inventory": 3600,
        "description": "Affordable residential neighborhood with great connectivity to L&T IT Park and Lanco Hills.",
        "highlights": ["Lanco Hills", "Lalitha Hospital", "ORR Proximity"]
    },
    {
        "name": "Bachupally",
        "state": "Telangana",
        "district": "Medchal-Malkajgiri",
        "mandal": "Quthbullapur",
        "town_city": "Hyderabad",
        "pincode": "500090",
        "latitude": 17.5320,
        "longitude": 78.3680,
        "avg_price_per_sqft": 4800,
        "avg_price_per_acre": 55000000,
        "avg_monthly_rent": 21000,
        "avg_rental_yield": 5.3,
        "annual_appreciation_rate": 9.0,
        "rental_demand_score": 82,
        "location_quality_score": 80,
        "growth_potential_score": 94,
        "total_inventory": 5800,
        "description": "Major education hub with prominent schools and universities, offering high entry-level yields.",
        "highlights": ["VNR VJIET", "Silver Oaks School", "Affordable Housing Corridor"]
    },
    {
        "name": "Madhapur",
        "state": "Telangana",
        "district": "Hyderabad",
        "mandal": "Khairatabad",
        "town_city": "Hyderabad",
        "pincode": "500081",
        "latitude": 17.4486,
        "longitude": 78.3908,
        "avg_price_per_sqft": 9800,
        "avg_price_per_acre": 160000000,
        "avg_monthly_rent": 46000,
        "avg_rental_yield": 4.9,
        "annual_appreciation_rate": 6.2,
        "rental_demand_score": 96,
        "location_quality_score": 95,
        "growth_potential_score": 82,
        "total_inventory": 3100,
        "description": "The pulse of IT dining and co-living with walking distance to tech parks.",
        "highlights": ["Durgam Cheruvu Cable Bridge", "NIFT", "Image Hospitals"]
    },

    # Prominent Agricultural & Semi-Urban Expansion Zones
    {
        "name": "Shankarpally Town",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Shankarpally",
        "town_city": "Shankarpally",
        "locality_village": "Shankarpally",
        "pincode": "501203",
        "latitude": 17.4490,
        "longitude": 78.1320,
        "avg_price_per_sqft": 3200,
        "avg_price_per_acre": 18000000,
        "avg_monthly_rent": 14000,
        "avg_rental_yield": 4.5,
        "annual_appreciation_rate": 11.5,
        "rental_demand_score": 75,
        "location_quality_score": 85,
        "growth_potential_score": 95,
        "total_inventory": 2200,
        "description": "Green farmland and weekend villa corridor with easy railway connectivity to Financial District.",
        "highlights": ["BDL Township", "Railway Station", "Green Belt", "Farm Houses"]
    },
    {
        "name": "Patancheru",
        "state": "Telangana",
        "district": "Sangareddy",
        "mandal": "Patancheru",
        "town_city": "Patancheru",
        "locality_village": "Patancheru",
        "pincode": "502319",
        "latitude": 17.5280,
        "longitude": 78.2670,
        "avg_price_per_sqft": 4200,
        "avg_price_per_acre": 35000000,
        "avg_monthly_rent": 19000,
        "avg_rental_yield": 5.4,
        "annual_appreciation_rate": 9.5,
        "rental_demand_score": 88,
        "location_quality_score": 82,
        "growth_potential_score": 91,
        "total_inventory": 3400,
        "description": "Major industrial & logistics corridor on NH 65 with strong workforce housing and plot demand.",
        "highlights": ["NH 65", "ICRISAT", "ORR Exit 3", "Industrial Estate"]
    },
    {
        "name": "Moinabad",
        "state": "Telangana",
        "district": "Rangareddy",
        "mandal": "Chevella",
        "town_city": "Moinabad",
        "locality_village": "Moinabad",
        "pincode": "501504",
        "latitude": 17.3290,
        "longitude": 78.2780,
        "avg_price_per_sqft": 2900,
        "avg_price_per_acre": 22000000,
        "avg_monthly_rent": 12000,
        "avg_rental_yield": 4.2,
        "annual_appreciation_rate": 12.0,
        "rental_demand_score": 70,
        "location_quality_score": 88,
        "growth_potential_score": 94,
        "total_inventory": 1900,
        "description": "Hyderabad's resort and premium organic farm haven near Himayat Sagar and Chevella Road.",
        "highlights": ["Chilkur Balaji", "Resort Belt", "Organic Farms", "Himayat Sagar"]
    },
    {
        "name": "Gajwel",
        "state": "Telangana",
        "district": "Siddipet",
        "mandal": "Gajwel",
        "town_city": "Gajwel",
        "locality_village": "Gajwel",
        "pincode": "502278",
        "latitude": 17.8510,
        "longitude": 78.6830,
        "avg_price_per_sqft": 2200,
        "avg_price_per_acre": 8500000,
        "avg_monthly_rent": 9500,
        "avg_rental_yield": 5.1,
        "annual_appreciation_rate": 10.0,
        "rental_demand_score": 68,
        "location_quality_score": 78,
        "growth_potential_score": 89,
        "total_inventory": 2800,
        "description": "Model horticulture corridor and agricultural hub with canal irrigation from Kaleshwaram project.",
        "highlights": ["Horticulture University", "Kaleshwaram Canal", "Rajiv Rahadari SH 1"]
    },
    {
        "name": "Vikarabad Town",
        "state": "Telangana",
        "district": "Vikarabad",
        "mandal": "Vikarabad",
        "town_city": "Vikarabad",
        "locality_village": "Vikarabad",
        "pincode": "501101",
        "latitude": 17.3360,
        "longitude": 77.9040,
        "avg_price_per_sqft": 2400,
        "avg_price_per_acre": 6500000,
        "avg_monthly_rent": 10500,
        "avg_rental_yield": 5.0,
        "annual_appreciation_rate": 9.2,
        "rental_demand_score": 65,
        "location_quality_score": 79,
        "growth_potential_score": 88,
        "total_inventory": 2100,
        "description": "Scenic hill country with red soil suitable for mango orchards, timber plantations, and eco-retreats.",
        "highlights": ["Ananthagiri Hills", "Eco-Tourism", "Timber Plantations", "Red Soil Belt"]
    },
    {
        "name": "Bhongir",
        "state": "Telangana",
        "district": "Yadadri Bhuvanagiri",
        "mandal": "Bhongir",
        "town_city": "Bhongir",
        "locality_village": "Bhongir",
        "pincode": "508116",
        "latitude": 17.5110,
        "longitude": 78.8890,
        "avg_price_per_sqft": 2600,
        "avg_price_per_acre": 9000000,
        "avg_monthly_rent": 11000,
        "avg_rental_yield": 4.8,
        "annual_appreciation_rate": 11.0,
        "rental_demand_score": 72,
        "location_quality_score": 80,
        "growth_potential_score": 92,
        "total_inventory": 3100,
        "description": "High growth highway corridor connecting Hyderabad to Yadadri Temple City along Warangal Highway.",
        "highlights": ["Bhongir Fort", "NH 163 Warangal Highway", "Yadadri Temple Proximity"]
    }
]

IMAGE_POOL_RESIDENTIAL = [
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80"
]

IMAGE_POOL_AGRI = [
    "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?auto=format&fit=crop&w=1200&q=80",
    "https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=1200&q=80"
]

PROPERTY_TITLES_RESIDENTIAL = [
    "Apex Elegance Luxury Residences",
    "Urban Sky Gated Community",
    "Crown Heights Ultra 3 BHK",
    "Serene Greens Villa Estate",
    "The Financial Tower Suite",
    "Greenwood Park Residences",
    "Solitaire Horizon Towers",
    "Prestige Highline Apartments",
    "Lakeside Boulevard Homes",
    "Oakwood Sanctuary Smart Homes"
]

PROPERTY_TITLES_AGRI = [
    "Sri Venkateshwara Organic Farm Estate",
    "Telangana Green Gold Mango Orchard",
    "High-Yield Sandy Loam Farmland",
    "Canal-Irrigated Agro Investment Parcel",
    "Ananthagiri Foothills Teak Plantation",
    "Gajwel Modern Dairy & Crop Farmland",
    "Shankarpally Eco Weekend Farm Plot",
    "Bhongir Highway Agricultural Land Holding",
    "Moinabad Countryside Agro Estate",
    "Patancheru Industrial Edge Agro Parcel"
]

def generate_properties(num_residential=40, num_agri=20):
    properties = []
    random.seed(42)
    prop_id = 1

    # 1. Generate Residential Properties
    for _ in range(num_residential):
        # Pick from residential localities
        res_locs = [l for l in LOCALITIES if l["avg_price_per_sqft"] >= 4500]
        loc = random.choice(res_locs)
        bhk = random.choice([2, 2, 3, 3, 3, 4, 4])
        
        if bhk == 2:
            area_sqft = random.randint(1100, 1450)
        elif bhk == 3:
            area_sqft = random.randint(1600, 2200)
        else:
            area_sqft = random.randint(2400, 3600)
            
        variation = random.uniform(0.88, 1.12)
        price_per_sqft = round(loc['avg_price_per_sqft'] * variation, 2)
        price = round(price_per_sqft * area_sqft)
        
        gross_yield = round(loc['avg_rental_yield'] * random.uniform(0.95, 1.05), 2)
        annual_rent = price * (gross_yield / 100.0)
        est_monthly_rent = round(annual_rent / 12.0)
        
        yield_score = min(100, int((gross_yield / 6.0) * 100))
        growth_score = loc['growth_potential_score']
        loc_score = loc['location_quality_score']
        demand_score = loc['rental_demand_score']
        value_score = random.randint(80, 95)
        
        investment_score = int(
            (yield_score * 0.30) +
            (growth_score * 0.25) +
            (loc_score * 0.15) +
            (demand_score * 0.10) +
            (value_score * 0.20)
        )
        
        is_verified = (prop_id % 3 == 0)
        is_featured = (prop_id in [1, 3, 7, 12, 18, 25])
        prop_title = f"{random.choice(PROPERTY_TITLES_RESIDENTIAL)} - {bhk} BHK"
        
        lat = loc['latitude'] + random.uniform(-0.012, 0.012)
        lng = loc['longitude'] + random.uniform(-0.012, 0.012)

        p = {
            "id": prop_id,
            "title": prop_title,
            "slug": f"prop-{prop_id}-{loc['name'].lower().replace(' ', '-')}-{bhk}bhk",
            "property_type": "Apartment" if bhk <= 3 else random.choice(["Apartment", "Villa"]),
            "purpose": "investment" if gross_yield >= 5.1 else "buy",
            "status": "Ready to Move" if prop_id % 2 == 0 else "Under Construction",
            "locality": loc['name'],
            "district": loc['district'],
            "mandal": loc['mandal'],
            "city": loc['town_city'],
            "state": "Telangana",
            "address": f"Plot {random.randint(10, 250)}, Near Main Road, {loc['name']}, {loc['district']} District, Telangana",
            "latitude": round(lat, 5),
            "longitude": round(lng, 5),
            "price": price,
            "area_sqft": area_sqft,
            "price_per_sqft": price_per_sqft,
            "bedrooms": bhk,
            "bathrooms": bhk if bhk <= 3 else bhk + 1,
            "balconies": 2 if bhk >= 3 else 1,
            "floor_number": random.randint(2, 18),
            "total_floors": 24,
            "age_years": random.randint(0, 5),
            "facing": random.choice(["East", "North-East", "North", "West"]),
            "est_monthly_rent": est_monthly_rent,
            "gross_rental_yield": gross_yield,
            "investment_score": investment_score,
            "growth_score": growth_score,
            "location_score": loc_score,
            "value_score": value_score,
            "is_verified": is_verified,
            "is_featured": is_featured,
            "is_synthetic": True,
            "data_source": "EstateIQ Synthetic Market Engine",
            "images": [
                random.choice(IMAGE_POOL_RESIDENTIAL),
                random.choice(IMAGE_POOL_RESIDENTIAL)
            ],
            "amenities": "Clubhouse, Swimming Pool, Gym, 24x7 Security, Children Play Area, Power Backup, EV Charging",
            
            # Agricultural Nulls
            "land_area_acres": None,
            "land_area_guntas": None,
            "price_per_acre": None,
            "survey_number": None,
            "soil_type": None,
            "irrigation_source": None,
            "road_access": None,
            "crop_type": None,
            "electricity_available": None,
            "fencing_available": None,
            "farmhouse_available": None,
            "expected_annual_crop_income": None,
            "agricultural_investment_score": None
        }
        properties.append(p)
        prop_id += 1

    # 2. Generate Agricultural Land Properties
    for _ in range(num_agri):
        agri_locs = [l for l in LOCALITIES if l.get("avg_price_per_acre", 0) > 0]
        loc = random.choice(agri_locs)
        
        acres = round(random.choice([1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 8.0, 10.0, 15.0]), 2)
        guntas = round(acres * 40.0, 1)
        area_sqft = round(acres * 43560.0)
        
        acre_price_variation = random.uniform(0.90, 1.15)
        price_per_acre = round(loc['avg_price_per_acre'] * acre_price_variation)
        total_price = round(price_per_acre * acres)
        price_per_sqft = round(total_price / area_sqft, 2)
        
        crop_type = random.choice(["Mango & Guava Orchard", "Paddy & Maize", "Cotton & Pulses", "Teak & Timber", "Organic Vegetables", "Turmeric & Chilli"])
        soil_type = random.choice(["Red Soil", "Black Cotton Soil", "Sandy Loam", "Alluvial Soil"])
        irrigation_source = random.choice(["Borewell (2 Wells)", "Canal Irrigation", "River Belt", "Drip Irrigation System"])
        road_access = random.choice(["BT Road", "Tar Road", "Mud Road", "Highway Facing"])
        agri_type = random.choice(["Agricultural Land", "Farm Land", "Orchard", "Plantation Land", "Farm House Land", "Agricultural Plot"])
        
        expected_annual_crop_income = round(total_price * random.uniform(0.035, 0.075))
        
        # Agricultural Investment Score (7-factor)
        agri_score = random.randint(76, 96)
        
        lat = loc['latitude'] + random.uniform(-0.02, 0.02)
        lng = loc['longitude'] + random.uniform(-0.02, 0.02)
        
        title = f"{acres:.1f} Acres {agri_type} in {loc['name']}"
        
        p = {
            "id": prop_id,
            "title": title,
            "slug": f"prop-{prop_id}-{loc['name'].lower().replace(' ', '-')}-{int(acres)}acre",
            "property_type": agri_type,
            "purpose": "investment",
            "status": "Ready to Move",
            "locality": loc['name'],
            "district": loc['district'],
            "mandal": loc['mandal'],
            "city": loc['town_city'],
            "state": "Telangana",
            "address": f"Survey No. {random.randint(100, 999)}, {loc['name']}, {loc['mandal']} Mandal, {loc['district']} District, Telangana",
            "latitude": round(lat, 5),
            "longitude": round(lng, 5),
            "price": total_price,
            "area_sqft": area_sqft,
            "price_per_sqft": price_per_sqft,
            "bedrooms": 0,
            "bathrooms": 0,
            "balconies": 0,
            "floor_number": 0,
            "total_floors": 0,
            "age_years": 0,
            "facing": "East",
            "est_monthly_rent": round(expected_annual_crop_income / 12.0),
            "gross_rental_yield": round((expected_annual_crop_income / total_price) * 100.0, 2),
            "investment_score": agri_score,
            "growth_score": loc['growth_potential_score'],
            "location_score": loc['location_quality_score'],
            "value_score": random.randint(82, 95),
            "is_verified": True,
            "is_featured": (prop_id % 5 == 0),
            "is_synthetic": True,
            "data_source": "EstateIQ Telangana Agri Intelligence",
            "images": [
                random.choice(IMAGE_POOL_AGRI),
                random.choice(IMAGE_POOL_AGRI)
            ],
            "amenities": f"{irrigation_source}, {road_access}, 3-Phase Electricity, Clear Title Patta Passbook",
            
            # Agricultural Fields
            "land_area_acres": acres,
            "land_area_guntas": guntas,
            "price_per_acre": price_per_acre,
            "survey_number": f"Sy. No. {random.randint(100, 890)}/{random.randint(1, 4)}",
            "soil_type": soil_type,
            "irrigation_source": irrigation_source,
            "road_access": road_access,
            "crop_type": crop_type,
            "electricity_available": True,
            "fencing_available": random.choice([True, False]),
            "farmhouse_available": random.choice([True, False]),
            "expected_annual_crop_income": expected_annual_crop_income,
            "agricultural_investment_score": agri_score
        }
        properties.append(p)
        prop_id += 1

    return properties

def generate_price_history():
    history = []
    years = [2021, 2022, 2023, 2024, 2025, 2026]
    
    for loc in LOCALITIES:
        base_price = loc['avg_price_per_sqft'] / ((1 + (loc['annual_appreciation_rate']/100)) ** 5)
        base_acre = (loc.get('avg_price_per_acre', 0) / ((1 + (loc['annual_appreciation_rate']/100)) ** 5)) if loc.get('avg_price_per_acre') else 0
        base_rent = loc['avg_monthly_rent'] / ((1 + 0.05) ** 5)
        
        for idx, yr in enumerate(years):
            appr = (1 + (loc['annual_appreciation_rate']/100)) ** idx
            rent_appr = (1 + 0.05) ** idx
            
            p_sqft = round(base_price * appr, 2)
            p_acre = round(base_acre * appr, 2) if base_acre else 0
            m_rent = round(base_rent * rent_appr)
            
            history.append({
                "locality": loc['name'],
                "district": loc['district'],
                "year": yr,
                "avg_price_per_sqft": p_sqft,
                "avg_price_per_acre": p_acre,
                "avg_monthly_rent": m_rent
            })
    return history

if __name__ == "__main__":
    props = generate_properties(num_residential=40, num_agri=20)
    hist = generate_price_history()
    
    with open(os.path.join(DATA_DIR, 'localities.json'), 'w') as f:
        json.dump(LOCALITIES, f, indent=2)
        
    with open(os.path.join(DATA_DIR, 'properties.json'), 'w') as f:
        json.dump(props, f, indent=2)
        
    with open(os.path.join(DATA_DIR, 'price_history.json'), 'w') as f:
        json.dump(hist, f, indent=2)
        
    pd.DataFrame(LOCALITIES).to_csv(os.path.join(DATA_DIR, 'localities.csv'), index=False)
    pd.DataFrame(props).to_csv(os.path.join(DATA_DIR, 'properties.csv'), index=False)
    pd.DataFrame(hist).to_csv(os.path.join(DATA_DIR, 'price_history.csv'), index=False)

    print(f"[SUCCESS] EstateIQ Dataset Generation Complete! {len(props)} properties ({len(LOCALITIES)} localities) saved to data/demo/")
