import os
import sys
import json

# Ensure project root is in python path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from app import create_app
from app.extensions import db
from app.models import (
    User, Location, Property, PropertyImage, PriceHistory,
    Lead, Advertisement, Subscription, AgriculturalDetails
)

def seed():
    app = create_app('development')
    with app.app_context():
        print("Re-creating database tables...")
        db.drop_all()
        db.create_all()

        # 1. Create Default Users
        admin = User(
            full_name="EstateIQ Admin",
            email="admin@estateiq.in",
            role="admin",
            company_name="EstateIQ Technologies Pvt Ltd"
        )
        admin.set_password("Admin@123")

        agent = User(
            full_name="Rajesh Kumar",
            email="rajesh.agent@estateiq.in",
            phone="+91 98765 43210",
            role="agent",
            company_name="Apex Realty Advisors",
            license_number="TS-RERA-2024-8849"
        )
        agent.set_password("Agent@123")

        owner = User(
            full_name="Srinivas Rao",
            email="srinivas.owner@gmail.com",
            phone="+91 91234 56789",
            role="owner"
        )
        owner.set_password("Owner@123")

        buyer = User(
            full_name="Ananya Sharma",
            email="ananya.buyer@gmail.com",
            phone="+91 99887 76655",
            role="buyer"
        )
        buyer.set_password("Buyer@123")

        db.session.add_all([admin, agent, owner, buyer])
        db.session.commit()
        print("[SUCCESS] Users seeded securely.")

        # 2. Seed Locations from JSON
        demo_dir = os.path.join(BASE_DIR, 'data', 'demo')
        with open(os.path.join(demo_dir, 'localities.json'), 'r') as f:
            localities_data = json.load(f)

        loc_map = {}
        for l_data in localities_data:
            loc = Location(
                name=l_data['name'],
                state=l_data.get('state', 'Telangana'),
                district=l_data.get('district', 'Hyderabad'),
                mandal=l_data.get('mandal', ''),
                town_city=l_data.get('town_city', l_data.get('city', 'Hyderabad')),
                locality_village=l_data.get('locality_village', l_data['name']),
                pincode=l_data.get('pincode', '500001'),
                location_type='locality',
                latitude=l_data.get('latitude'),
                longitude=l_data.get('longitude'),
                avg_price_per_sqft=l_data.get('avg_price_per_sqft', 0.0),
                avg_price_per_acre=l_data.get('avg_price_per_acre', 0.0),
                avg_monthly_rent=l_data.get('avg_monthly_rent', 0.0),
                avg_rental_yield=l_data.get('avg_rental_yield', 0.0),
                annual_appreciation_rate=l_data.get('annual_appreciation_rate', 7.5),
                rental_demand_score=l_data.get('rental_demand_score', 80),
                location_quality_score=l_data.get('location_quality_score', 85),
                growth_potential_score=l_data.get('growth_potential_score', 85),
                total_inventory=l_data.get('total_inventory', 1000),
                description=l_data.get('description', ''),
                highlights=", ".join(l_data.get('highlights', [])) if isinstance(l_data.get('highlights'), list) else l_data.get('highlights', ''),
                is_synthetic=True,
                data_source="EstateIQ Telangana Master Dataset v2.0"
            )
            db.session.add(loc)
            db.session.flush()
            loc_map[l_data['name']] = loc.id

        db.session.commit()
        print(f"[SUCCESS] {len(loc_map)} Locations seeded with Telangana administrative hierarchy.")

        # 3. Seed Price History
        with open(os.path.join(demo_dir, 'price_history.json'), 'r') as f:
            history_data = json.load(f)

        for h in history_data:
            if h['locality'] in loc_map:
                ph = PriceHistory(
                    location_id=loc_map[h['locality']],
                    year=h['year'],
                    avg_price_per_sqft=h.get('avg_price_per_sqft', 0.0),
                    avg_price_per_acre=h.get('avg_price_per_acre', 0.0),
                    avg_monthly_rent=h.get('avg_monthly_rent', 0.0)
                )
                db.session.add(ph)

        db.session.commit()
        print("[SUCCESS] Historical price data seeded.")

        # 4. Seed Properties
        with open(os.path.join(demo_dir, 'properties.json'), 'r') as f:
            props_data = json.load(f)

        for p_data in props_data:
            loc_id = loc_map.get(p_data['locality'])
            if not loc_id:
                continue

            assigned_user_id = agent.id if p_data['id'] % 2 == 0 else owner.id

            score_details = json.dumps({
                "yield_score": min(100, int((p_data.get('gross_rental_yield', 5.0) / 6.0) * 100)),
                "growth_score": p_data.get('growth_score', 85),
                "location_score": p_data.get('location_score', 88),
                "value_score": p_data.get('value_score', 87)
            })

            prop = Property(
                title=p_data['title'],
                slug=p_data['slug'],
                description=f"Premium {p_data['bedrooms']} BHK {p_data['property_type']} in {p_data['locality']}. High appreciation potential with strong returns." if p_data['bedrooms'] > 0 else f"Prime {p_data.get('land_area_acres', 2)} Acres {p_data['property_type']} in {p_data['locality']}, {p_data.get('district', 'Rangareddy')} District. Clear title with fertile soil and great connectivity.",
                property_type=p_data['property_type'],
                purpose=p_data.get('purpose', 'buy'),
                status=p_data.get('status', 'Ready to Move'),
                location_id=loc_id,
                address=p_data.get('address'),
                latitude=p_data.get('latitude'),
                longitude=p_data.get('longitude'),
                price=p_data['price'],
                area_sqft=p_data['area_sqft'],
                price_per_sqft=p_data.get('price_per_sqft', 0.0),
                bedrooms=p_data.get('bedrooms', 0),
                bathrooms=p_data.get('bathrooms', 0),
                balconies=p_data.get('balconies', 0),
                floor_number=p_data.get('floor_number', 0),
                total_floors=p_data.get('total_floors', 0),
                age_years=p_data.get('age_years', 0),
                facing=p_data.get('facing', 'East'),
                est_monthly_rent=p_data.get('est_monthly_rent', 0.0),
                gross_rental_yield=p_data.get('gross_rental_yield', 0.0),
                investment_score=p_data.get('investment_score', 80),
                growth_score=p_data.get('growth_score', 85),
                location_score=p_data.get('location_score', 88),
                value_score=p_data.get('value_score', 87),
                score_breakdown_json=score_details,
                is_verified=p_data.get('is_verified', True),
                is_featured=p_data.get('is_featured', False),
                is_synthetic=True,
                data_source=p_data.get('data_source', 'EstateIQ Telangana Intelligence'),
                verification_status='Verified' if p_data.get('is_verified', True) else 'Pending',
                user_id=assigned_user_id,
                contact_person=agent.full_name if assigned_user_id == agent.id else owner.full_name,
                contact_phone=agent.phone if assigned_user_id == agent.id else owner.phone,
                contact_email=agent.email if assigned_user_id == agent.id else owner.email,
                amenities=p_data.get('amenities', ''),
                
                # Direct agricultural columns on Property
                land_area_acres=p_data.get('land_area_acres'),
                land_area_guntas=p_data.get('land_area_guntas'),
                price_per_acre=p_data.get('price_per_acre'),
                survey_number=p_data.get('survey_number'),
                soil_type=p_data.get('soil_type'),
                irrigation_source=p_data.get('irrigation_source'),
                road_access=p_data.get('road_access'),
                crop_type=p_data.get('crop_type'),
                electricity_available=p_data.get('electricity_available'),
                fencing_available=p_data.get('fencing_available'),
                farmhouse_available=p_data.get('farmhouse_available'),
                expected_annual_crop_income=p_data.get('expected_annual_crop_income'),
                agricultural_investment_score=p_data.get('agricultural_investment_score')
            )
            db.session.add(prop)
            db.session.flush()

            # Seed images
            for idx, img_url in enumerate(p_data.get('images', [])):
                img = PropertyImage(
                    property_id=prop.id,
                    image_url=img_url,
                    is_primary=(idx == 0)
                )
                db.session.add(img)

            # If agricultural, also create AgriculturalDetails record
            if prop.is_agricultural and p_data.get('land_area_acres'):
                details = AgriculturalDetails(
                    property_id=prop.id,
                    acres=p_data['land_area_acres'],
                    guntas=p_data.get('land_area_guntas', p_data['land_area_acres'] * 40.0),
                    cents=round(p_data['land_area_acres'] * 100.0, 2),
                    total_sqft=p_data['area_sqft'],
                    survey_number=p_data.get('survey_number', f"Sy. No. {prop.id * 13 + 7}"),
                    land_type="Agricultural Patta",
                    irrigation_source=p_data.get('irrigation_source', 'Borewell'),
                    road_access=p_data.get('road_access', 'BT Road'),
                    soil_type=p_data.get('soil_type', 'Red Soil'),
                    crop_type=p_data.get('crop_type', 'Organic Vegetables / Orchard'),
                    electricity_available=True,
                    fencing_available=p_data.get('fencing_available', False),
                    farmhouse_available=p_data.get('farmhouse_available', False),
                    expected_annual_crop_income=p_data.get('expected_annual_crop_income', 0.0),
                    agricultural_investment_score=p_data.get('agricultural_investment_score', 85)
                )
                db.session.add(details)

        db.session.commit()
        print(f"[SUCCESS] {len(props_data)} Properties seeded (with Residential & Agricultural categories).")

        # 5. Seed Sample Leads
        sample_lead = Lead(
            property_id=1,
            user_id=buyer.id,
            sender_name="Ananya Sharma",
            sender_email="ananya.buyer@gmail.com",
            sender_phone="+91 99887 76655",
            message="Hi, I am interested in evaluating this property for investment purposes. Please share site visit schedule and documentation.",
            preferred_contact_time="Evening (5 PM - 8 PM)",
            status="New"
        )
        db.session.add(sample_lead)

        # 6. Seed Monetization / Ad Slots
        ad1 = Advertisement(
            slot_type="homepage_banner",
            title="Pre-Launch: Kokapet Golden Mile Luxury Suites",
            description="Ultra-spacious 3 & 4 BHK apartments with panoramic Gandipet lake views. 100% Vastu.",
            advertiser_name="Apex Developers",
            target_url="https://estateiq.in",
            impressions=1240,
            clicks=88,
            is_active=True
        )
        ad2 = Advertisement(
            slot_type="property_detail_sidebar",
            title="Low-Interest Home Loans @ 8.35%",
            description="Instant pre-approval with zero processing fee for verified EstateIQ properties.",
            advertiser_name="HDFC Home Loans",
            target_url="https://estateiq.in",
            impressions=3420,
            clicks=215,
            is_active=True
        )
        db.session.add_all([ad1, ad2])
        db.session.commit()
        print("[SUCCESS] Monetization ad slots seeded.")
        print("[SUCCESS] Database initialization completed successfully.")

if __name__ == '__main__':
    seed()
