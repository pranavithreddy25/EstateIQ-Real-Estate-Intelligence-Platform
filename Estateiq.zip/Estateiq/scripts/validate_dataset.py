"""
EstateIQ Dataset Validator & Bulk Import Quality Engine.
Validates property & location CSV/JSON datasets against schema,
geographic coordinates (Telangana bounding box), and financial integrity.

Usage:
    python scripts/validate_dataset.py [path_to_file]
"""
import sys
import os
import json
import pandas as pd

# Telangana Geographic Bounding Box
TELANGANA_BOUNDS = {
    'min_lat': 15.80,
    'max_lat': 19.95,
    'min_lng': 77.20,
    'max_lng': 81.85,
}

VALID_PROPERTY_TYPES = [
    'Apartment', 'Villa', 'Independent House', 'Commercial', 'Plot',
    'Agricultural Land', 'Farm Land', 'Orchard', 'Plantation Land',
    'Farm House Land', 'Agricultural Plot'
]

REQUIRED_FIELDS = ['title', 'price', 'property_type']


def validate_file(file_path):
    print("=" * 65)
    print(f"  EstateIQ Dataset Validator: {os.path.basename(file_path)}")
    print("=" * 65)

    if not os.path.exists(file_path):
        print(f"ERROR: File '{file_path}' does not exist.")
        return False

    # Load data
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.json':
        with open(file_path, 'r', encoding='utf-8') as f:
            records = json.load(f)
    elif ext in ('.csv', '.txt'):
        df = pd.read_csv(file_path)
        records = df.to_dict(orient='records')
    elif ext in ('.xlsx', '.xls'):
        df = pd.read_excel(file_path)
        records = df.to_dict(orient='records')
    else:
        print(f"ERROR: Unsupported file format '{ext}'. Supported: .json, .csv, .xlsx")
        return False

    if not isinstance(records, list):
        print("ERROR: Dataset must contain a list of records.")
        return False

    total = len(records)
    valid_count = 0
    errors = []

    for idx, row in enumerate(records, start=1):
        row_errors = []

        # 1. Required fields
        for field in REQUIRED_FIELDS:
            val = row.get(field)
            if val is None or (isinstance(val, str) and not val.strip()):
                row_errors.append(f"Missing required field '{field}'")

        # 2. Price check
        price = row.get('price')
        if price is not None:
            try:
                p_val = float(price)
                if p_val <= 0:
                    row_errors.append(f"Price must be positive (got {p_val})")
            except (ValueError, TypeError):
                row_errors.append(f"Invalid price value '{price}'")

        # 3. Property Type check
        ptype = row.get('property_type')
        if ptype and ptype not in VALID_PROPERTY_TYPES:
            row_errors.append(f"Invalid property_type '{ptype}'. Allowed: {', '.join(VALID_PROPERTY_TYPES[:4])}...")

        # 4. Coordinates within Telangana bounds
        lat = row.get('latitude')
        lng = row.get('longitude')
        if lat is not None and lng is not None and pd.notna(lat) and pd.notna(lng):
            try:
                lat_f = float(lat)
                lng_f = float(lng)
                if not (TELANGANA_BOUNDS['min_lat'] <= lat_f <= TELANGANA_BOUNDS['max_lat']):
                    row_errors.append(f"Latitude {lat_f} outside Telangana bounds ({TELANGANA_BOUNDS['min_lat']}-{TELANGANA_BOUNDS['max_lat']})")
                if not (TELANGANA_BOUNDS['min_lng'] <= lng_f <= TELANGANA_BOUNDS['max_lng']):
                    row_errors.append(f"Longitude {lng_f} outside Telangana bounds ({TELANGANA_BOUNDS['min_lng']}-{TELANGANA_BOUNDS['max_lng']})")
            except (ValueError, TypeError):
                row_errors.append("Latitude/Longitude must be numeric")

        if row_errors:
            errors.append({'row': idx, 'title': row.get('title', 'Unknown'), 'errors': row_errors})
        else:
            valid_count += 1

    # Report Summary
    print(f"\nTotal Records Inspected: {total}")
    print(f"Valid Records:           {valid_count} ({(valid_count/total*100):.1f}%)" if total > 0 else "0")
    print(f"Records with Issues:     {len(errors)}")

    if errors:
        print("\nValidation Issues Breakdown (Top 10):")
        for err in errors[:10]:
            print(f"  • Row {err['row']} ('{err['title']}'): {', '.join(err['errors'])}")
        if len(errors) > 10:
            print(f"  ... and {len(errors) - 10} more rows with warnings.")
    else:
        print("\n✓ SUCCESS: All records passed schema, financial, and geographic validation!")

    print("=" * 65)
    return len(errors) == 0


if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    target = sys.argv[1] if len(sys.argv) > 1 else os.path.join(base_dir, 'data', 'demo', 'properties.json')
    validate_file(target)
