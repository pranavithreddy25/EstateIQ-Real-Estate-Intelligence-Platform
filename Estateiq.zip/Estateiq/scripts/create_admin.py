"""Secure CLI tool to create an admin user for EstateIQ.

Usage:
    python scripts/create_admin.py

This script prompts for admin credentials interactively and never
exposess passwords in plain text in source code or configuration files.
"""
import sys
import os
import getpass

# Ensure the project root is on the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from app.extensions import db
from app.models import User

app = create_app()


def main():
    print("\n" + "=" * 60)
    print("  EstateIQ — Secure Admin Account Setup")
    print("=" * 60)
    print("This script creates or updates the admin account.")
    print("Passwords are securely hashed — never stored in plain text.\n")

    full_name = input("Admin Full Name [EstateIQ Administrator]: ").strip() or "EstateIQ Administrator"
    email = input("Admin Email: ").strip().lower()

    if not email or '@' not in email:
        print("ERROR: A valid email address is required.")
        sys.exit(1)

    password = getpass.getpass("Admin Password (hidden): ")
    confirm = getpass.getpass("Confirm Password (hidden): ")

    if password != confirm:
        print("ERROR: Passwords do not match.")
        sys.exit(1)

    if len(password) < 8:
        print("ERROR: Password must be at least 8 characters.")
        sys.exit(1)

    with app.app_context():
        existing = User.query.filter_by(email=email).first()
        if existing:
            if existing.role != 'admin':
                print(f"WARNING: User {email} exists but is not an admin. Upgrading role to admin.")
                existing.role = 'admin'
            existing.full_name = full_name
            existing.set_password(password)
            db.session.commit()
            print(f"\n✓ Admin account updated for: {email}")
        else:
            user = User(
                full_name=full_name,
                email=email,
                role='admin',
            )
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            print(f"\n✓ Admin account created for: {email}")
        print("  Please keep your credentials in a secure password manager.")
        print("  DO NOT share or hardcode passwords in source files.\n")


if __name__ == '__main__':
    main()
