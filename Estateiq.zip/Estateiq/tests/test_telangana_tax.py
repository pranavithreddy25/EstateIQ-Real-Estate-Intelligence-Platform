import unittest
from app.analytics.telangana_tax import calculate_telangana_registration_cost

class TestTelanganaTaxCalculator(unittest.TestCase):

    def test_urban_ready_to_move_registration(self):
        # ₹1 Crore property ready to move
        res = calculate_telangana_registration_cost(agreed_price=10000000)
        self.assertEqual(res.stamp_duty, 400000.0)      # 4.0%
        self.assertEqual(res.transfer_duty, 150000.0)   # 1.5%
        self.assertEqual(res.registration_fee, 50000.0) # 0.5%
        self.assertEqual(res.total_registration_charges, 600000.0) # 6.0% Total
        self.assertEqual(res.gst_amount, 0.0)           # 0% on Ready to Move
        self.assertEqual(res.tds_amount, 100000.0)      # 1.0% TDS under Sec 194-IA (>= ₹50L)

    def test_under_construction_gst(self):
        # Under construction non-affordable
        res = calculate_telangana_registration_cost(agreed_price=10000000, status="Under Construction")
        self.assertEqual(res.gst_rate_pct, 5.0)
        self.assertEqual(res.gst_amount, 500000.0)

    def test_agricultural_dharani_registration(self):
        # Agricultural land registration
        res = calculate_telangana_registration_cost(agreed_price=5000000, property_type="Agricultural Land")
        self.assertEqual(res.stamp_duty, 200000.0)      # 4%
        self.assertEqual(res.registration_fee, 2500.0)   # Dharani mutation fee

if __name__ == '__main__':
    unittest.main()
