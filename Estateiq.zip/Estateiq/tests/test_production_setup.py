import unittest
import os
from app import create_app
from app.utils.payment import RazorpayManager

class TestProductionSetup(unittest.TestCase):

    def setUp(self):
        self.app = create_app('development')
        self.app_context = self.app.app_context()
        self.app_context.push()

    def tearDown(self):
        self.app_context.pop()

    def test_dockerfile_and_compose_exist(self):
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        self.assertTrue(os.path.exists(os.path.join(base_dir, 'Dockerfile')))
        self.assertTrue(os.path.exists(os.path.join(base_dir, 'docker-compose.yml')))
        self.assertTrue(os.path.exists(os.path.join(base_dir, 'nginx', 'default.conf')))

    def test_payment_manager_sandbox_fallback(self):
        pm = RazorpayManager()
        order = pm.create_order(amount_inr=999.0, receipt="test_rcpt")
        self.assertIn('id', order)
        self.assertEqual(order['amount'], 99900)
        self.assertTrue(order.get('is_sandbox', False))

        is_valid = pm.verify_payment_signature(order['id'], 'pay_mock123', 'sig_mock123')
        self.assertTrue(is_valid)

if __name__ == '__main__':
    unittest.main()
