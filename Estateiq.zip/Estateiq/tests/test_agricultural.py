import unittest
from app.analytics.land_converter import convert_land_area, normalize_to_standard, price_per_unit
from app.analytics.agricultural_roi import compute_agricultural_roi, compare_agri_vs_residential, AgriROIInput

class TestAgriculturalAnalytics(unittest.TestCase):

    def test_land_unit_conversions(self):
        # 1 Acre = 40 Guntas = 43,560 sq.ft
        self.assertEqual(convert_land_area(1, 'acres', 'guntas'), 40.0)
        self.assertEqual(convert_land_area(1, 'acres', 'sqft'), 43560.0)
        
        normalized = normalize_to_standard(acres=2.5)
        self.assertEqual(normalized['guntas'], 100.0)
        self.assertEqual(normalized['sqft'], 108900.0)

    def test_price_per_unit(self):
        # 1 Crore for 2 Acres => 50 Lakh/Acre
        prices = price_per_unit(10000000, acres=2.0)
        self.assertEqual(prices['per_acre'], 5000000.0)
        self.assertEqual(prices['per_gunta'], 125000.0)

    def test_agri_roi_scenarios(self):
        inp = AgriROIInput(
            purchase_price=5000000,
            land_area_acres=2.0,
            annual_crop_income=150000,
            annual_expenses=30000,
            holding_years=10
        )
        res = compute_agricultural_roi(inp)
        self.assertGreater(res.moderate.net_profit, 0)
        self.assertGreater(res.investment_score, 0)

    def test_agri_vs_residential_comparator(self):
        res = compare_agri_vs_residential(
            agri_purchase_price=5000000,
            agri_appreciation_pct=10.0,
            resi_purchase_price=5000000,
            resi_appreciation_pct=7.0,
            resi_monthly_rent=25000
        )
        self.assertIn(res['winner'], ['agricultural', 'residential'])

if __name__ == '__main__':
    unittest.main()
