import unittest
from app import create_app
from app.extensions import db
from app.models.location import Location

class TestTelanganaLocationHierarchy(unittest.TestCase):

    def setUp(self):
        self.app = create_app('development')
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.client = self.app.test_client()

    def tearDown(self):
        self.app_context.pop()

    def test_location_full_string(self):
        loc = Location(
            name="Kokapet",
            state="Telangana",
            district="Rangareddy",
            mandal="Gandipet",
            locality_village="Kokapet"
        )
        self.assertEqual(loc.full_location_string(), "Kokapet, Gandipet Mandal, Rangareddy District, Telangana")

    def test_api_districts_endpoint(self):
        res = self.client.get('/api/locations/districts')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('districts', data)

    def test_api_mandals_endpoint(self):
        res = self.client.get('/api/locations/mandals?district=Rangareddy')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('mandals', data)

if __name__ == '__main__':
    unittest.main()
