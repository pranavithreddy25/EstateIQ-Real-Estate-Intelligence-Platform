import unittest
from app import create_app

class TestAdsModule(unittest.TestCase):

    def setUp(self):
        self.app = create_app('development')
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.client = self.app.test_client()

    def tearDown(self):
        self.app_context.pop()

    def test_ads_txt_route(self):
        res = self.client.get('/ads.txt')
        self.assertEqual(res.status_code, 200)
        self.assertIn('text/plain', res.content_type)

    def test_ad_manager_extension_registered(self):
        self.assertIn('ads', self.app.extensions)

if __name__ == '__main__':
    unittest.main()
