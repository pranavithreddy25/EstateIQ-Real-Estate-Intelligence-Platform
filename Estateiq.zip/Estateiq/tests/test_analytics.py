import unittest
from app.analytics.calculators import calculate_rental_yield, calculate_emi, calculate_roi, calculate_buy_vs_rent
from app.analytics.scoring import compute_investment_score

class TestFinancialCalculators(unittest.TestCase):

    def test_rental_yield(self):
        # 78 Lakh property with 35,000 monthly rent
        res = calculate_rental_yield(7800000, 35000)
        self.assertAlmostEqual(res['gross_yield'], 5.38, places=1)
        self.assertEqual(res['annual_gross_rent'], 420000)

    def test_emi_calculation(self):
        # 60 Lakh principal at 8.5% interest for 20 years
        res = calculate_emi(6000000, annual_interest_rate=8.5, tenure_years=20)
        self.assertTrue(res['emi'] > 50000)
        self.assertEqual(len(res['yearly_schedule']), 20)

    def test_investment_score(self):
        # High yield property should score >= 80
        score_res = compute_investment_score(
            gross_yield=5.5,
            growth_potential_score=90,
            location_quality_score=92,
            rental_demand_score=90,
            price=7800000,
            target_budget=8000000
        )
        self.assertGreaterEqual(score_res['score'], 80)
        self.assertTrue(len(score_res['explanations']) > 0)

    def test_buy_vs_rent(self):
        res = calculate_buy_vs_rent(8000000, 32000, years=10)
        self.assertIn(res['recommendation'], ['Buy', 'Rent'])
        self.assertTrue(res['buying']['final_property_value'] > 8000000)

if __name__ == '__main__':
    unittest.main()
