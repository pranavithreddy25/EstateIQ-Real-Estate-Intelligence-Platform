import unittest
from app import create_app
from app.extensions import db
from app.models import User

class TestAuthSecurity(unittest.TestCase):

    def setUp(self):
        self.app = create_app('development')
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.client = self.app.test_client()

    def tearDown(self):
        self.app_context.pop()

    def test_password_hashing(self):
        user = User(full_name="Test User", email="security_test@estateiq.in", role="user")
        user.set_password("SuperSecretPass123!")
        
        self.assertNotEqual(user.password_hash, "SuperSecretPass123!")
        self.assertTrue(user.check_password("SuperSecretPass123!"))
        self.assertFalse(user.check_password("WrongPassword"))

    def test_login_page_does_not_expose_passwords(self):
        res = self.client.get('/auth/login')
        self.assertEqual(res.status_code, 200)
        html = res.get_data(as_text=True)
        self.assertNotIn('Admin@123', html)
        self.assertNotIn('password_hash', html)

    def test_unauthorized_admin_access(self):
        res = self.client.get('/admin/dashboard', follow_redirects=True)
        # Should redirect unauthenticated user to login
        self.assertIn('Sign in', res.get_data(as_text=True))

if __name__ == '__main__':
    unittest.main()
