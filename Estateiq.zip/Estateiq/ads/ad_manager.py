"""Ad slot loader and central manager for EstateIQ."""
from flask import render_template_string
from ads.config import AD_SLOTS
from ads.providers.google_adsense import render_adsense_slot


class AdManager:
    def __init__(self, app):
        self.app = app
        self.enabled = app.config.get('ADS_ENABLED', False)
        self.provider = app.config.get('ADS_PROVIDER', 'google_adsense')
        self.client_id = app.config.get('ADSENSE_CLIENT_ID', '')
        self._slot_overrides = {}  # Admin can toggle individual slots

        # Register Jinja global so templates can call ads(slot_id)
        @app.context_processor
        def inject_ads():
            return {'render_ad_slot': self.render_slot}

    def is_slot_enabled(self, slot_id: str) -> bool:
        if not self.enabled:
            return False
        # Check per-slot override (set via admin panel)
        return self._slot_overrides.get(slot_id, True)

    def enable_slot(self, slot_id: str):
        self._slot_overrides[slot_id] = True

    def disable_slot(self, slot_id: str):
        self._slot_overrides[slot_id] = False

    def render_slot(self, slot_id: str) -> str:
        """Render an ad slot HTML for the given slot_id.
        Returns empty string if ads are disabled.
        """
        if not self.is_slot_enabled(slot_id):
            return ''
        slot_config = AD_SLOTS.get(slot_id)
        if not slot_config:
            return ''
        if self.provider == 'google_adsense':
            return render_adsense_slot(slot_id, slot_config, self.client_id)
        return ''

    def get_all_slots(self) -> list:
        """Return all defined slots with their enabled status."""
        slots = []
        for slot_id, cfg in AD_SLOTS.items():
            slots.append({
                'id': slot_id,
                'label': cfg['label'],
                'size': cfg['size'],
                'enabled': self.is_slot_enabled(slot_id),
            })
        return slots
