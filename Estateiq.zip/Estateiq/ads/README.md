# EstateIQ Advertisement & Monetization Module (`ads/`)

Decoupled advertising and monetization package for EstateIQ PropTech Platform.

## Features
1. **Decoupled Architecture**: Fully isolated from core logic. Can be globally enabled/disabled via `.env` flag `ADS_ENABLED=true/false`.
2. **Google AdSense Integration**: Native compliance with `/ads.txt` automated route rendering.
3. **Dynamic Slot Management**: Admin console can toggle individual ad slots on/off dynamically at runtime.
4. **Predefined Slots**:
   - `homepage_top` (728x90)
   - `property_listing_middle` (336x280)
   - `property_detail_top` (728x90)
   - `property_detail_sidebar` (300x250)
   - `investment_sidebar` (300x250)
   - `agricultural_listing` (336x280)
   - `footer_banner` (728x90)

## Configuration
Set in `.env`:
```env
ADS_ENABLED=true
ADS_PROVIDER=google_adsense
ADSENSE_CLIENT_ID=ca-pub-1234567890123456
```

## Template Usage
In any Jinja template:
```html
{{ render_ad_slot('homepage_top') }}
```
