"""
Pre-defined Ad Slots for EstateIQ Monetization Architecture.
"""

HOMEPAGE_TOP = "homepage_top"
PROPERTY_LISTING_MIDDLE = "property_listing_middle"
PROPERTY_DETAIL_TOP = "property_detail_top"
PROPERTY_DETAIL_SIDEBAR = "property_detail_sidebar"
INVESTMENT_SIDEBAR = "investment_sidebar"
FOOTER_BANNER = "footer_banner"
AGRICULTURAL_LISTING = "agricultural_listing"

DEFAULT_SLOTS = [
    {
        "id": HOMEPAGE_TOP,
        "label": "Homepage Top Hero Banner",
        "size": "728x90",
        "description": "High visibility banner placed above the market discovery section on homepage."
    },
    {
        "id": PROPERTY_LISTING_MIDDLE,
        "label": "Property Search Grid — Mid Insert",
        "size": "336x280",
        "description": "Native card placed within property search grid between listing cards."
    },
    {
        "id": PROPERTY_DETAIL_TOP,
        "label": "Property Detail Top Banner",
        "size": "728x90",
        "description": "Prominent top banner below the property photo gallery."
    },
    {
        "id": PROPERTY_DETAIL_SIDEBAR,
        "label": "Property Detail Sidebar Widget",
        "size": "300x250",
        "description": "Sticky sidebar ad below agent contact card for financial/mortgage offers."
    },
    {
        "id": INVESTMENT_SIDEBAR,
        "label": "Investment Tools Sidebar",
        "size": "300x250",
        "description": "Placed adjacent to EMI, ROI, and Buy vs Rent calculators."
    },
    {
        "id": AGRICULTURAL_LISTING,
        "label": "Agricultural Farmland Listing Insert",
        "size": "336x280",
        "description": "Contextual ad for borewell, fencing, farm management, or agro loans."
    },
    {
        "id": FOOTER_BANNER,
        "label": "Statewide Footer Banner",
        "size": "728x90",
        "description": "Statewide bottom banner displayed across all public discovery routes."
    }
]
