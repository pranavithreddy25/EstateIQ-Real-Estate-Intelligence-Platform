"""EstateIQ Advertisement Module.

This module is fully decoupled from the rest of the application.
All ad-related code lives here. The main app only calls:
    from ads import init_ads
    init_ads(app)

Set ADS_ENABLED=false in config to disable all ads globally.
"""
from .ad_manager import AdManager

_manager: AdManager = None


def init_ads(app):
    """Initialize the ads module with the Flask app."""
    global _manager
    _manager = AdManager(app)
    app.extensions['ads'] = _manager

    # Register /ads.txt route
    @app.route('/ads.txt')
    def ads_txt():
        from flask import Response, current_app
        client_id = current_app.config.get('ADSENSE_CLIENT_ID', '')
        if client_id and current_app.config.get('ADS_ENABLED', False):
            content = f"google.com, {client_id}, DIRECT, f08c47fec0942fa0"
        else:
            content = "# Ads not configured. Set ADS_ENABLED=true and ADSENSE_CLIENT_ID in .env"
        return Response(content, mimetype='text/plain')

    return _manager


def get_manager() -> AdManager:
    return _manager
