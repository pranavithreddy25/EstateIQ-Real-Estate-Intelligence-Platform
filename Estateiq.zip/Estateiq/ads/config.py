"""Advertisement configuration defaults."""
import os

ADS_ENABLED = os.environ.get('ADS_ENABLED', 'false').lower() == 'true'
ADS_PROVIDER = os.environ.get('ADS_PROVIDER', 'google_adsense')  # google_adsense | custom
ADSENSE_CLIENT_ID = os.environ.get('ADSENSE_CLIENT_ID', '')

# Defined ad slots and their display labels
AD_SLOTS = {
    'homepage_top': {
        'label': 'Homepage — Top Banner',
        'size': '728x90',
        'responsive': True,
    },
    'property_listing_middle': {
        'label': 'Property Listing — Middle',
        'size': '336x280',
        'responsive': True,
    },
    'property_detail_top': {
        'label': 'Property Detail — Top',
        'size': '728x90',
        'responsive': True,
    },
    'property_detail_sidebar': {
        'label': 'Property Detail — Sidebar',
        'size': '300x250',
        'responsive': True,
    },
    'investment_sidebar': {
        'label': 'Investment Tools — Sidebar',
        'size': '300x250',
        'responsive': True,
    },
    'footer_banner': {
        'label': 'Footer Banner',
        'size': '728x90',
        'responsive': True,
    },
    'agricultural_listing': {
        'label': 'Agricultural Land Listing',
        'size': '336x280',
        'responsive': True,
    },
}
