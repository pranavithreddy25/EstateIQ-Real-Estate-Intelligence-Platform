"""Google AdSense slot renderer for EstateIQ."""
from markupsafe import Markup


ADSENSE_SCRIPT = """
<!-- EstateIQ AdSense -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={client_id}"
     crossorigin="anonymous"></script>
"""

AD_SLOT_TEMPLATE = """
<div class="ad-slot-wrapper ad-slot-{slot_id}" aria-label="Advertisement">
  <ins class="adsbygoogle"
       style="display:block"
       data-ad-client="{client_id}"
       data-ad-slot="{slot_id}"
       data-ad-format="auto"
       data-full-width-responsive="true"></ins>
  <script>
       (adsbygoogle = window.adsbygoogle || []).push({{}});
  </script>
</div>
"""


def render_adsense_slot(slot_id: str, slot_config: dict, client_id: str) -> str:
    """Return the full AdSense HTML markup for the given slot."""
    if not client_id or client_id == 'ca-pub-XXXXXXXXXXXXXXXX':
        # Return placeholder in development
        html = f"""
        <div class="ad-slot-wrapper ad-placeholder" style="
            background: linear-gradient(135deg, #f5f5f7 0%, #e8e8ed 100%);
            border: 1px dashed #c7c7cc;
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            color: #6e6e73;
            font-size: 12px;
            letter-spacing: 0.05em;
            min-height: 90px;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <span>Ad Slot: <strong>{slot_id}</strong> — {slot_config['size']} — Configure ADSENSE_CLIENT_ID in .env</span>
        </div>
        """
        return Markup(html)

    return Markup(AD_SLOT_TEMPLATE.format(
        slot_id=slot_id,
        client_id=client_id,
    ))
