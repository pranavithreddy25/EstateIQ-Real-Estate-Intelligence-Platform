"""
EstateIQ Payment Gateway Integration Module (Razorpay).
Provides order creation, HMAC signature verification, and sandbox fallback.
"""
import os
import hmac
import hashlib
from typing import Dict, Any


class RazorpayManager:
    def __init__(self, key_id: str = None, key_secret: str = None):
        self.key_id = key_id or os.environ.get('RAZORPAY_KEY_ID', '')
        self.key_secret = key_secret or os.environ.get('RAZORPAY_KEY_SECRET', '')
        self.enabled = bool(self.key_id and self.key_secret)

    def create_order(self, amount_inr: float, currency: str = "INR", receipt: str = None, notes: dict = None) -> Dict[str, Any]:
        """
        Create a Razorpay order.
        Amount is converted to paise (1 INR = 100 paise).
        """
        amount_paise = int(amount_inr * 100)
        
        if not self.enabled:
            # Dev Sandbox Fallback
            import uuid
            mock_order_id = f"order_mock_{uuid.uuid4().hex[:12]}"
            return {
                'id': mock_order_id,
                'entity': 'order',
                'amount': amount_paise,
                'amount_paid': 0,
                'amount_due': amount_paise,
                'currency': currency,
                'receipt': receipt or 'rcpt_mock',
                'status': 'created',
                'attempts': 0,
                'notes': notes or {},
                'is_sandbox': True
            }

        try:
            import razorpay
            client = razorpay.Client(auth=(self.key_id, self.key_secret))
            data = {
                'amount': amount_paise,
                'currency': currency,
                'receipt': receipt or 'rcpt_estateiq',
                'notes': notes or {}
            }
            return client.order.create(data=data)
        except Exception as e:
            raise RuntimeError(f"Razorpay order creation failed: {str(e)}")

    def verify_payment_signature(self, razorpay_order_id: str, razorpay_payment_id: str, razorpay_signature: str) -> bool:
        """
        Verify payment webhook/callback HMAC SHA256 signature.
        """
        if not self.enabled:
            # Dev sandbox always approves mock orders
            return razorpay_order_id.startswith('order_mock_') or True

        msg = f"{razorpay_order_id}|{razorpay_payment_id}".encode('utf-8')
        generated_signature = hmac.new(
            self.key_secret.encode('utf-8'),
            msg,
            hashlib.sha256
        ).hexdigest()

        return hmac.compare_digest(generated_signature, razorpay_signature)


# Singleton Instance
payment_manager = RazorpayManager()
