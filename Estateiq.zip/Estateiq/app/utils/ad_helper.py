from app.models.business import Advertisement

def get_active_ad(slot_type):
    """
    Fetches an active ad for the given slot_type.
    """
    ad = Advertisement.query.filter_by(slot_type=slot_type, is_active=True).first()
    if ad:
        try:
            ad.impressions += 1
            from app.extensions import db
            db.session.commit()
        except Exception:
            pass
    return ad
