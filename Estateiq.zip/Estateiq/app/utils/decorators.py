from functools import wraps
from flask import redirect, url_for, flash, abort, request
from flask_login import current_user

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please sign in to access this page.', 'error')
            return redirect(url_for('auth.login', next=request.url))
        if not current_user.is_admin():
            flash('Administrator privileges required to access this resource.', 'error')
            return redirect(url_for('public.index'))
        return f(*args, **kwargs)
    return decorated_function

def agent_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please sign in to access this page.', 'error')
            return redirect(url_for('auth.login', next=request.url))
        if not (current_user.is_agent() or current_user.is_admin()):
            flash('Registered Real Estate Agent or Admin access required.', 'error')
            return redirect(url_for('public.index'))
        return f(*args, **kwargs)
    return decorated_function

def owner_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please sign in to access this page.', 'error')
            return redirect(url_for('auth.login', next=request.url))
        if not (current_user.is_owner() or current_user.is_admin()):
            flash('Owner or Agent access required to submit listings.', 'error')
            return redirect(url_for('public.index'))
        return f(*args, **kwargs)
    return decorated_function
