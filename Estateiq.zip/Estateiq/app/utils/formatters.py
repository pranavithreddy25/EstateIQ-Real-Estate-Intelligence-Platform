def format_currency(amount):
    if amount is None:
        return "₹0"
    return f"₹{format_number(amount)}"

def format_number(val):
    if val is None:
        return "0"
    formatted = f"{float(val):.0f}"
    sign = ""
    if formatted.startswith("-"):
        sign, formatted = "-", formatted[1:]
    if len(formatted) <= 3:
        return sign + formatted
    last_three = formatted[-3:]
    leading = formatted[:-3]
    groups = []
    while len(leading) > 2:
        groups.insert(0, leading[-2:])
        leading = leading[:-2]
    if leading:
        groups.insert(0, leading)
    return sign + ",".join(groups + [last_three])
