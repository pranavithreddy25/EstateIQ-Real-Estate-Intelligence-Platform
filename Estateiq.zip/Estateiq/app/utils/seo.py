import json

def generate_property_jsonld(prop):
    """
    Generates Schema.org SingleFamilyResidence / RealEstateListing JSON-LD schema.
    """
    schema = {
        "@context": "https://schema.org",
        "@type": "RealEstateListing",
        "name": prop.title,
        "description": prop.description or f"{prop.bedrooms} BHK {prop.property_type} in {prop.location_rel.name if prop.location_rel else ''}",
        "url": f"/properties/{prop.id}",
        "datePosted": prop.created_at.strftime('%Y-%m-%d') if prop.created_at else "2026-01-01",
        "offers": {
            "@type": "Offer",
            "priceCurrency": "INR",
            "price": prop.price,
            "availability": "https://schema.org/InStock"
        }
    }
    return json.dumps(schema)
