"""
Official Telangana Real Estate Registration, Stamp Duty & Tax Calculator.
Grounded in Telangana Registration & Stamps Department Rules (registration.telangana.gov.in)
and Income Tax Act Section 194-IA (TDS on Immovable Property).
"""

from dataclasses import dataclass

# Telangana Registration Fee Breakdown
STAMP_DUTY_PCT = 4.0        # 4.0% Stamp Duty
TRANSFER_DUTY_PCT = 1.5     # 1.5% Transfer Duty
REGISTRATION_FEE_PCT = 0.5  # 0.5% Registration Fee
TOTAL_GOVT_REGISTRATION_PCT = STAMP_DUTY_PCT + TRANSFER_DUTY_PCT + REGISTRATION_FEE_PCT  # 6.0% Total

# Agricultural Land Registration Rate (Telangana Dharani Rule)
AGRI_STAMP_DUTY_PCT = 4.0
AGRI_MUTATION_FEE = 2500.0  # Fixed Dharani mutation charge in INR


@dataclass
class TelanganaTaxBreakdown:
    agreed_price: float
    govt_market_value: float
    taxable_base_value: float
    stamp_duty: float
    transfer_duty: float
    registration_fee: float
    total_registration_charges: float
    gst_rate_pct: float
    gst_amount: float
    tds_rate_pct: float
    tds_amount: float
    total_acquisition_cost: float


def calculate_telangana_registration_cost(
    agreed_price: float,
    govt_market_value: float = None,
    property_type: str = "Apartment",
    status: str = "Ready to Move",
    is_affordable: bool = False
) -> TelanganaTaxBreakdown:
    """
    Calculate authentic Telangana government registration, stamp duty, GST, and TDS charges.
    
    Rules:
    1. Base value is MAX(Agreed Price, Govt Basic Value).
    2. Total Registration Charges = 7.5% (4% Stamp + 1.5% Transfer + 0.5% Reg Fee).
    3. GST:
       - Ready to Move (with OC/CC): 0%
       - Under Construction (Affordable <= ₹45L & <= 60 sqm): 1%
       - Under Construction (Non-Affordable): 5%
    4. TDS (Section 194-IA):
       - 1.0% if property purchase price >= ₹50,000,000 (₹50 Lakhs).
    """
    if govt_market_value is None:
        # Default govt basic value estimate (~85% of market price in urban TS)
        govt_market_value = agreed_price * 0.85

    taxable_base = max(agreed_price, govt_market_value)

    if property_type in ['Agricultural Land', 'Farm Land', 'Orchard', 'Plantation Land']:
        # Agricultural Registration via Dharani Portal
        stamp_duty = round(taxable_base * (AGRI_STAMP_DUTY_PCT / 100), 2)
        transfer_duty = 0.0
        registration_fee = AGRI_MUTATION_FEE
        total_reg = stamp_duty + registration_fee
        gst_rate = 0.0  # No GST on raw agricultural land
    else:
        # Urban Residential / Commercial Registration
        stamp_duty = round(taxable_base * (STAMP_DUTY_PCT / 100), 2)
        transfer_duty = round(taxable_base * (TRANSFER_DUTY_PCT / 100), 2)
        registration_fee = round(taxable_base * (REGISTRATION_FEE_PCT / 100), 2)
        total_reg = round(taxable_base * (TOTAL_GOVT_REGISTRATION_PCT / 100), 2)

        # GST Logic
        if status == 'Ready to Move':
            gst_rate = 0.0
        elif is_affordable or agreed_price <= 4500000:
            gst_rate = 1.0
        else:
            gst_rate = 5.0

    gst_amount = round(agreed_price * (gst_rate / 100), 2)

    # Section 194-IA TDS
    if agreed_price >= 5000000:
        tds_rate = 1.0
        tds_amount = round(agreed_price * 0.01, 2)
    else:
        tds_rate = 0.0
        tds_amount = 0.0

    total_cost = round(agreed_price + total_reg + gst_amount, 2)

    return TelanganaTaxBreakdown(
        agreed_price=agreed_price,
        govt_market_value=govt_market_value,
        taxable_base_value=taxable_base,
        stamp_duty=stamp_duty,
        transfer_duty=transfer_duty,
        registration_fee=registration_fee,
        total_registration_charges=total_reg,
        gst_rate_pct=gst_rate,
        gst_amount=gst_amount,
        tds_rate_pct=tds_rate,
        tds_amount=tds_amount,
        total_acquisition_cost=total_cost
    )
