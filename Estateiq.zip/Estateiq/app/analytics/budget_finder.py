from app.models import Location, Property
from app.analytics.scoring import compute_investment_score
from app.analytics.calculators import calculate_roi, calculate_emi
from app.utils.formatters import format_currency

def analyze_budget_investment(budget, city="Hyderabad", purpose="investment", property_type=None, bedrooms=None):
    """
    Core engine behind the 'I Have ₹80 Lakh' feature.
    Analyzes database properties and localities to deliver tailored investment recommendations.
    """
    # 1. Fetch matching locations
    locations = Location.query.filter_by(town_city=city).all()
    
    location_rankings = []
    for loc in locations:
        # Check average budget affordability
        avg_property_cost_3bhk = loc.avg_price_per_sqft * 1800
        avg_property_cost_2bhk = loc.avg_price_per_sqft * 1250
        
        affordability_score = 100
        if budget < avg_property_cost_2bhk * 0.8:
            affordability_score = 50
        elif budget < avg_property_cost_3bhk:
            affordability_score = 80
            
        location_score = int(
            (loc.avg_rental_yield * 10) * 0.35 +
            (loc.annual_appreciation_rate * 8) * 0.30 +
            loc.rental_demand_score * 0.20 +
            affordability_score * 0.15
        )
        
        location_rankings.append({
            "location_id": loc.id,
            "name": loc.name,
            "avg_price_per_sqft": loc.avg_price_per_sqft,
            "avg_rental_yield": loc.avg_rental_yield,
            "annual_appreciation_rate": loc.annual_appreciation_rate,
            "rental_demand_score": loc.rental_demand_score,
            "growth_potential_score": loc.growth_potential_score,
            "location_score": location_score,
            "sample_2bhk_price": round(avg_property_cost_2bhk),
            "sample_3bhk_price": round(avg_property_cost_3bhk)
        })

    # Sort locations by score descending
    location_rankings.sort(key=lambda x: x['location_score'], reverse=True)
    top_locations = location_rankings[:5]

    # 2. Fetch and evaluate matching properties
    query = Property.query.join(Location).filter(Location.town_city == city)
    if property_type and property_type != "All":
        query = query.filter(Property.property_type == property_type)
    if bedrooms:
        query = query.filter(Property.bedrooms == bedrooms)

    # Filter properties up to 1.15x budget for flexibility
    all_props = query.filter(Property.price <= budget * 1.15).all()

    evaluated_props = []
    for prop in all_props:
        score_res = compute_investment_score(
            gross_yield=prop.gross_rental_yield,
            growth_potential_score=prop.location_rel.growth_potential_score if prop.location_rel else 80,
            location_quality_score=prop.location_rel.location_quality_score if prop.location_rel else 85,
            rental_demand_score=prop.location_rel.rental_demand_score if prop.location_rel else 80,
            price=prop.price,
            target_budget=budget,
            age_years=prop.age_years,
            status=prop.status
        )

        roi_data = calculate_roi(
            purchase_price=prop.price,
            down_payment_pct=20,
            initial_monthly_rent=prop.est_monthly_rent,
            annual_appreciation_pct=prop.location_rel.annual_appreciation_rate if prop.location_rel else 7.5,
            holding_years=10
        )

        emi_data = calculate_emi(principal=prop.price * 0.8)

        # Why this property text
        why_text = (
            f"Fits your budget closely ({'within budget' if prop.price <= budget else 'slightly above budget'}). "
            f"Delivers an estimated rental yield of {prop.gross_rental_yield:.2f}% (approx {format_currency(prop.est_monthly_rent)}/mo) "
            f"with an Investment Score of {score_res['score']}/100."
        )

        evaluated_props.append({
            "property": prop,
            "investment_score": score_res['score'],
            "rating_label": score_res['rating_label'],
            "badge_color": score_res['badge_color'],
            "score_explanations": score_res['explanations'],
            "roi_analysis": roi_data,
            "emi": emi_data['emi'],
            "why_this_property": why_text
        })

    # Sort properties by investment score
    evaluated_props.sort(key=lambda x: x['investment_score'], reverse=True)
    top_properties = evaluated_props[:6]

    return {
        "budget": budget,
        "budget_formatted": format_currency(budget),
        "purpose": purpose,
        "city": city,
        "top_locations": top_locations,
        "top_properties": top_properties,
        "total_matches_found": len(evaluated_props)
    }
