"""
Agricultural Land ROI & Investment Intelligence Engine.
Provides Scenario Analysis (Conservative, Moderate, Optimistic),
Agricultural Investment Score (0-100), and Agri vs Residential Comparator.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AgriROIInput:
    purchase_price: float             # Total price in INR
    land_area_acres: float            # Area in Acres
    annual_crop_income: float = 0.0   # Net crop income per year in INR
    annual_expenses: float = 0.0      # Maintenance, labour, seeds, water per year in INR
    holding_years: int = 10

    # Capital Appreciation Scenarios (% per year)
    conservative_appreciation: float = 5.0
    moderate_appreciation: float = 9.0
    optimistic_appreciation: float = 14.0

    # Crop Income Growth (%/yr)
    conservative_income_growth: float = 3.0
    moderate_income_growth: float = 5.0
    optimistic_income_growth: float = 7.0

    # Agricultural Investment Score Factors (0-100 each)
    land_value_score: int = 75        # Value relative to market
    water_score: int = 80             # Irrigation reliability
    road_score: int = 75              # Road accessibility
    location_growth_score: int = 85   # District/Mandal growth potential
    income_potential_score: int = 75  # Crop income potential
    development_score: int = 70       # Future development potential


@dataclass
class ScenarioResult:
    name: str
    final_land_value: float
    total_crop_income: float
    total_expenses: float
    net_profit: float
    roi_percent: float
    cagr_percent: float
    annual_breakdown: list = field(default_factory=list)


@dataclass
class AgriROIResult:
    purchase_price: float
    land_area_acres: float
    conservative: ScenarioResult
    moderate: ScenarioResult
    optimistic: ScenarioResult
    investment_score: int
    score_breakdown: dict
    price_per_acre: float


def _compute_scenario(
    name: str,
    purchase_price: float,
    annual_crop_income: float,
    annual_expenses: float,
    holding_years: int,
    appreciation_pct: float,
    income_growth_pct: float,
) -> ScenarioResult:
    land_value = purchase_price
    total_crop = 0.0
    total_exp = 0.0
    crop = annual_crop_income
    exp = annual_expenses
    breakdown = []

    for yr in range(1, holding_years + 1):
        land_value *= (1 + appreciation_pct / 100)
        net_income = crop - exp
        total_crop += crop
        total_exp += exp
        breakdown.append({
            'year': yr,
            'land_value': round(land_value),
            'crop_income': round(crop),
            'expenses': round(exp),
            'net_income': round(net_income),
        })
        crop *= (1 + income_growth_pct / 100)
        exp *= 1.04  # 4% expense inflation

    capital_gain = land_value - purchase_price
    net_profit = capital_gain + total_crop - total_exp
    roi_pct = (net_profit / purchase_price) * 100 if purchase_price > 0 else 0
    total_end_value = land_value + total_crop - total_exp
    cagr = ((total_end_value / purchase_price) ** (1 / holding_years) - 1) * 100 if purchase_price > 0 else 0

    return ScenarioResult(
        name=name,
        final_land_value=round(land_value),
        total_crop_income=round(total_crop),
        total_expenses=round(total_exp),
        net_profit=round(net_profit),
        roi_percent=round(roi_pct, 2),
        cagr_percent=round(cagr, 2),
        annual_breakdown=breakdown,
    )


def compute_agricultural_roi(inp: AgriROIInput) -> AgriROIResult:
    """Full agricultural ROI with Conservative, Moderate, Optimistic scenarios."""
    conservative = _compute_scenario(
        'Conservative', inp.purchase_price, inp.annual_crop_income, inp.annual_expenses,
        inp.holding_years, inp.conservative_appreciation, inp.conservative_income_growth
    )
    moderate = _compute_scenario(
        'Moderate', inp.purchase_price, inp.annual_crop_income, inp.annual_expenses,
        inp.holding_years, inp.moderate_appreciation, inp.moderate_income_growth
    )
    optimistic = _compute_scenario(
        'Optimistic', inp.purchase_price, inp.annual_crop_income, inp.annual_expenses,
        inp.holding_years, inp.optimistic_appreciation, inp.optimistic_income_growth
    )

    score, breakdown = _compute_agri_investment_score(
        land_value_score=inp.land_value_score,
        appreciation_pct=inp.moderate_appreciation,
        water_score=inp.water_score,
        road_score=inp.road_score,
        location_growth_score=inp.location_growth_score,
        income_potential_score=inp.income_potential_score,
        development_score=inp.development_score,
    )

    return AgriROIResult(
        purchase_price=inp.purchase_price,
        land_area_acres=inp.land_area_acres,
        conservative=conservative,
        moderate=moderate,
        optimistic=optimistic,
        investment_score=score,
        score_breakdown=breakdown,
        price_per_acre=round(inp.purchase_price / inp.land_area_acres, 2) if inp.land_area_acres > 0 else 0,
    )


def _compute_agri_investment_score(
    land_value_score: int,
    appreciation_pct: float,
    water_score: int,
    road_score: int,
    location_growth_score: int,
    income_potential_score: int,
    development_score: int,
) -> tuple:
    """
    7-Factor Agricultural Investment Score (0-100).
    Weights:
      Land Price Value:      20%
      Capital Appreciation:  25%
      Water / Irrigation:    15%
      Road Access:           10%
      Location Growth:       15%
      Agricultural Income:   10%
      Development Potential:  5%
    """
    # Normalize appreciation to 0-100 (0-15% range benchmark: 12% = 80, 15% = 100)
    appr_norm = min(100.0, max(0.0, (appreciation_pct / 15.0) * 100.0))

    weights = {
        'Land Price Value (20%)': (float(land_value_score), 0.20),
        'Capital Appreciation (25%)': (appr_norm, 0.25),
        'Water / Irrigation (15%)': (float(water_score), 0.15),
        'Road Access (10%)': (float(road_score), 0.10),
        'Location Growth (15%)': (float(location_growth_score), 0.15),
        'Agricultural Income (10%)': (float(income_potential_score), 0.10),
        'Development Potential (5%)': (float(development_score), 0.05),
    }

    total = sum(score * weight for score, weight in weights.values())
    breakdown = {k: {'score': round(v[0]), 'weight_pct': int(v[1] * 100)} for k, v in weights.items()}
    return max(0, min(100, round(total))), breakdown


def compare_agri_vs_residential(
    agri_purchase_price: float,
    agri_appreciation_pct: float = 9.0,
    agri_annual_income: float = 0.0,
    resi_purchase_price: float = None,
    resi_appreciation_pct: float = 7.5,
    resi_monthly_rent: float = 0.0,
    holding_years: int = 10,
) -> dict:
    """Side-by-side Agricultural vs Residential investment comparison."""
    if resi_purchase_price is None:
        resi_purchase_price = agri_purchase_price

    def compute_simple(price, appr_pct, annual_income, years):
        val = price
        income = 0.0
        for _ in range(years):
            val *= (1 + appr_pct / 100)
            income += annual_income
        return val - price + income

    agri_profit = compute_simple(agri_purchase_price, agri_appreciation_pct, agri_annual_income, holding_years)
    resi_annual = resi_monthly_rent * 12
    resi_profit = compute_simple(resi_purchase_price, resi_appreciation_pct, resi_annual, holding_years)

    agri_roi = (agri_profit / agri_purchase_price) * 100 if agri_purchase_price > 0 else 0
    resi_roi = (resi_profit / resi_purchase_price) * 100 if resi_purchase_price > 0 else 0

    return {
        'agricultural': {
            'purchase_price': agri_purchase_price,
            'appreciation_pct': agri_appreciation_pct,
            'net_profit': round(agri_profit),
            'roi_pct': round(agri_roi, 2),
        },
        'residential': {
            'purchase_price': resi_purchase_price,
            'appreciation_pct': resi_appreciation_pct,
            'net_profit': round(resi_profit),
            'roi_pct': round(resi_roi, 2),
        },
        'winner': 'agricultural' if agri_roi > resi_roi else 'residential',
        'diff_roi_pct': round(abs(agri_roi - resi_roi), 2),
    }
