import math
from app.utils.formatters import format_currency

def calculate_rental_yield(price, monthly_rent, maintenance_monthly=0, vacancy_months=0.5, annual_tax=0):
    """
    Calculates Gross and Net Rental Yield percentages.
    """
    if price <= 0:
        return {"gross_yield": 0.0, "net_yield": 0.0, "annual_gross_rent": 0.0, "annual_net_rent": 0.0}

    annual_gross_rent = monthly_rent * 12.0
    gross_yield = (annual_gross_rent / price) * 100.0

    # Net yield adjustments
    annual_vacancy_loss = monthly_rent * vacancy_months
    annual_maintenance = maintenance_monthly * 12.0
    total_expenses = annual_vacancy_loss + annual_maintenance + annual_tax

    annual_net_rent = max(0.0, annual_gross_rent - total_expenses)
    net_yield = (annual_net_rent / price) * 100.0

    return {
        "gross_yield": round(gross_yield, 2),
        "net_yield": round(net_yield, 2),
        "annual_gross_rent": round(annual_gross_rent, 2),
        "annual_net_rent": round(annual_net_rent, 2),
        "total_annual_expenses": round(total_expenses, 2)
    }

def calculate_emi(principal, annual_interest_rate=8.5, tenure_years=20):
    """
    Calculates monthly EMI, total interest payable, total payment, and schedule breakdown.
    Formula: EMI = P * r * (1+r)^n / ((1+r)^n - 1)
    """
    if principal <= 0 or tenure_years <= 0:
        return {"emi": 0, "total_interest": 0, "total_payment": 0, "principal": principal}

    monthly_rate = (annual_interest_rate / 100.0) / 12.0
    num_months = tenure_years * 12

    if monthly_rate == 0:
        emi = principal / num_months
    else:
        emi = principal * monthly_rate * math.pow(1 + monthly_rate, num_months) / (math.pow(1 + monthly_rate, num_months) - 1)

    total_payment = emi * num_months
    total_interest = total_payment - principal

    # Yearly breakdown schedule (up to tenure_years)
    yearly_schedule = []
    balance = principal
    for year in range(1, tenure_years + 1):
        year_interest = 0
        year_principal = 0
        for month in range(12):
            m_interest = balance * monthly_rate
            m_principal = emi - m_interest
            year_interest += m_interest
            year_principal += m_principal
            balance -= m_principal

        yearly_schedule.append({
            "year": year,
            "interest_paid": round(year_interest),
            "principal_paid": round(year_principal),
            "remaining_balance": max(0, round(balance))
        })

    return {
        "emi": round(emi),
        "monthly_emi_formatted": format_currency(round(emi)),
        "principal": round(principal),
        "total_interest": round(total_interest),
        "total_payment": round(total_payment),
        "tenure_years": tenure_years,
        "annual_interest_rate": annual_interest_rate,
        "yearly_schedule": yearly_schedule
    }

def calculate_roi(purchase_price, down_payment_pct=20, loan_interest_rate=8.5, tenure_years=20,
                  initial_monthly_rent=35000, annual_appreciation_pct=7.5, rent_growth_pct=5.0, holding_years=10):
    """
    Complete Real Estate ROI analysis over holding period.
    """
    down_payment = purchase_price * (down_payment_pct / 100.0)
    loan_amount = purchase_price - down_payment
    emi_data = calculate_emi(loan_amount, loan_interest_rate, tenure_years)
    monthly_emi = emi_data['emi']

    total_rent_collected = 0.0
    current_rent = initial_monthly_rent

    for yr in range(holding_years):
        total_rent_collected += current_rent * 12.0
        current_rent *= (1 + (rent_growth_pct / 100.0))

    future_property_value = purchase_price * math.pow(1 + (annual_appreciation_pct / 100.0), holding_years)

    # Remaining loan balance at holding_years end
    if holding_years < tenure_years and len(emi_data['yearly_schedule']) >= holding_years:
        remaining_loan = emi_data['yearly_schedule'][holding_years - 1]['remaining_balance']
    else:
        remaining_loan = 0

    total_emi_paid = monthly_emi * 12 * holding_years
    total_cash_invested = down_payment + total_emi_paid

    net_sale_proceeds = future_property_value - remaining_loan
    total_return = net_sale_proceeds + total_rent_collected - total_cash_invested
    roi_pct = (total_return / total_cash_invested) * 100.0 if total_cash_invested > 0 else 0
    annualized_roi = (math.pow(1 + (roi_pct / 100.0), 1.0 / holding_years) - 1) * 100.0 if roi_pct > -100 else 0

    return {
        "purchase_price": purchase_price,
        "down_payment": round(down_payment),
        "loan_amount": round(loan_amount),
        "monthly_emi": monthly_emi,
        "holding_years": holding_years,
        "future_property_value": round(future_property_value),
        "total_rent_collected": round(total_rent_collected),
        "total_cash_invested": round(total_cash_invested),
        "net_profit": round(total_return),
        "total_roi_pct": round(roi_pct, 2),
        "annualized_roi_pct": round(annualized_roi, 2)
    }

def calculate_buy_vs_rent(property_price, monthly_rent, down_payment_pct=20, loan_interest_rate=8.5,
                           appreciation_pct=7.0, rent_inflation_pct=5.0, stock_return_pct=10.0, years=10):
    """
    Compares Buying property vs Renting + Investing surplus in index funds over a given timeline.
    """
    down_payment = property_price * (down_payment_pct / 100.0)
    loan_amount = property_price - down_payment
    emi_data = calculate_emi(loan_amount, loan_interest_rate, tenure_years=years)
    monthly_emi = emi_data['emi']

    # Scenario 1: Buying
    buying_property_value = property_price * math.pow(1 + (appreciation_pct / 100.0), years)
    buying_total_outflow = down_payment + (monthly_emi * 12 * years)
    buying_net_worth = buying_property_value  # Assume loan fully paid in 'years'

    # Scenario 2: Renting
    renting_corpus = down_payment  # Initial capital invested in stocks
    renting_total_outflow = 0.0
    current_rent = monthly_rent

    for yr in range(years):
        annual_rent = current_rent * 12
        renting_total_outflow += annual_rent
        
        # Grow initial corpus
        renting_corpus *= (1 + (stock_return_pct / 100.0))
        
        # Monthly surplus invested if EMI > rent
        monthly_surplus = max(0, monthly_emi - current_rent)
        renting_corpus += (monthly_surplus * 12) * (1 + (stock_return_pct / 100.0) / 2)
        
        current_rent *= (1 + (rent_inflation_pct / 100.0))

    buying_advantage = buying_net_worth - renting_corpus

    return {
        "timeline_years": years,
        "property_price": property_price,
        "buying": {
            "final_property_value": round(buying_property_value),
            "total_outflow": round(buying_total_outflow),
            "net_worth": round(buying_net_worth)
        },
        "renting": {
            "final_investment_corpus": round(renting_corpus),
            "total_rent_paid": round(renting_total_outflow),
            "net_worth": round(renting_corpus)
        },
        "recommendation": "Buy" if buying_advantage > 0 else "Rent",
        "buying_advantage": round(abs(buying_advantage)),
        "explainable_summary": (
            f"Over {years} years, purchasing is estimated to yield a net worth of {format_currency(round(buying_net_worth))} "
            f"compared to renting and investing equity yields {format_currency(round(renting_corpus))}."
        )
    }
