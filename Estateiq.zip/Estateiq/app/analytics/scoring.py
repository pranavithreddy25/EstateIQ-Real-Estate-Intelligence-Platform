def compute_investment_score(gross_yield, growth_potential_score, location_quality_score,
                             rental_demand_score, price=None, target_budget=None,
                             age_years=2, status="Ready to Move"):
    """
    Computes a transparent 0-100 Investment Score with explainable factors.
    """
    # 1. Rental Yield Factor (30% weight) -> benchmark 5.5% gross yield = 100 pts
    yield_factor = min(100.0, (gross_yield / 5.5) * 100.0)
    
    # 2. Growth Potential Factor (25% weight)
    growth_factor = float(growth_potential_score or 80)
    
    # 3. Location Quality Factor (15% weight)
    location_factor = float(location_quality_score or 85)
    
    # 4. Rental Demand Factor (10% weight)
    demand_factor = float(rental_demand_score or 80)
    
    # 5. Budget Fit Factor (15% weight)
    if price and target_budget and target_budget > 0:
        ratio = price / target_budget
        if 0.8 <= ratio <= 1.05:
            budget_factor = 95.0
        elif 0.6 <= ratio < 0.8:
            budget_factor = 85.0
        elif ratio < 0.6:
            budget_factor = 75.0
        else: # ratio > 1.05
            budget_factor = max(40.0, 100.0 - ((ratio - 1.05) * 100))
    else:
        budget_factor = 85.0

    # 6. Property Feature / Condition (5% weight)
    feature_factor = 90.0 if status == "Ready to Move" else 80.0
    if age_years <= 2:
        feature_factor += 5.0
    feature_factor = min(100.0, feature_factor)

    # Weighted Average
    score = int(
        (yield_factor * 0.30) +
        (growth_factor * 0.25) +
        (location_factor * 0.15) +
        (budget_factor * 0.15) +
        (demand_factor * 0.10) +
        (feature_factor * 0.05)
    )
    score = max(0, min(100, score))

    # Rating Tier
    if score >= 88:
        rating_label = "Exceptional Investment Potential"
        badge_color = "emerald"
    elif score >= 78:
        rating_label = "Strong Investment Potential"
        badge_color = "green"
    elif score >= 68:
        rating_label = "Moderate Investment Potential"
        badge_color = "amber"
    else:
        rating_label = "Low Investment Potential"
        badge_color = "red"

    # Bulleted Explanations
    reasons = []
    if gross_yield >= 5.0:
        reasons.append(f"Strong estimated rental yield of {gross_yield:.2f}%, outperforming city average.")
    elif gross_yield >= 4.2:
        reasons.append(f"Competitive rental yield of {gross_yield:.2f}%.")
    else:
        reasons.append(f"Rental yield of {gross_yield:.2f}% is lower than optimal investor benchmarks.")

    if growth_factor >= 88:
        reasons.append("High capital appreciation potential driven by upcoming infrastructure & tech corridor expansion.")
    
    if location_factor >= 88:
        reasons.append("Prime location grade with excellent school, hospital, and commercial connectivity.")

    if demand_factor >= 88:
        reasons.append("High tenant demand ensuring minimal vacancy risks.")

    if target_budget and price:
        if price <= target_budget:
            from app.utils.formatters import format_currency
            reasons.append(f"Comfortably fits within your target budget of {format_currency(target_budget)}.")
        else:
            reasons.append(f"Exceeds target budget by {((price/target_budget)-1)*100:.1f}%.")

    return {
        "score": score,
        "rating_label": rating_label,
        "badge_color": badge_color,
        "breakdown": {
            "yield_score": int(yield_factor),
            "growth_score": int(growth_factor),
            "location_score": int(location_factor),
            "budget_score": int(budget_factor),
            "demand_score": int(demand_factor),
            "feature_score": int(feature_factor)
        },
        "explanations": reasons
    }
