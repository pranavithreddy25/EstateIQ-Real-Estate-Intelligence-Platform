"""
Land Area Unit Converter for Telangana Agricultural Properties.
Standard Conversions:
  1 Acre      = 40 Guntas
  1 Acre      = 100 Cents
  1 Acre      = 4,840 Square Yards
  1 Acre      = 43,560 Square Feet
  1 Gunta     = 121 Square Yards
  1 Gunta     = 1,089 Square Feet
  1 Cent      = 435.6 Square Feet
  1 Cent      = 48.4 Square Yards
"""

ACRE_TO_SQFT = 43_560.0
ACRE_TO_SQYD = 4_840.0
ACRE_TO_GUNTA = 40.0
ACRE_TO_CENT = 100.0
GUNTA_TO_SQFT = 1_089.0
GUNTA_TO_SQYD = 121.0
CENT_TO_SQFT = 435.6
CENT_TO_SQYD = 48.4


def to_acres(value: float, unit: str) -> float:
    """Convert any land unit to Acres."""
    unit = unit.lower().strip()
    if unit in ('acre', 'acres'):
        return value
    elif unit in ('gunta', 'guntas', 'gunta(s)'):
        return value / ACRE_TO_GUNTA
    elif unit in ('cent', 'cents'):
        return value / ACRE_TO_CENT
    elif unit in ('sqft', 'sq.ft', 'square feet', 'squarefeet'):
        return value / ACRE_TO_SQFT
    elif unit in ('sqyd', 'sq.yd', 'square yards', 'squareyards'):
        return value / ACRE_TO_SQYD
    else:
        raise ValueError(f"Unknown land unit: {unit}")


def convert_land_area(value: float, from_unit: str, to_unit: str) -> float:
    """Convert land area between any two supported units."""
    acres = to_acres(value, from_unit)
    to_unit = to_unit.lower().strip()
    if to_unit in ('acre', 'acres'):
        return acres
    elif to_unit in ('gunta', 'guntas'):
        return acres * ACRE_TO_GUNTA
    elif to_unit in ('cent', 'cents'):
        return acres * ACRE_TO_CENT
    elif to_unit in ('sqft', 'sq.ft', 'square feet'):
        return acres * ACRE_TO_SQFT
    elif to_unit in ('sqyd', 'sq.yd', 'square yards'):
        return acres * ACRE_TO_SQYD
    else:
        raise ValueError(f"Unknown target unit: {to_unit}")


def normalize_to_standard(acres: float = None, guntas: float = None, cents: float = None,
                           sqft: float = None, sqyd: float = None) -> dict:
    """
    Given any one measurement, compute all standard representations.
    Priority: acres > guntas > cents > sqft > sqyd
    """
    if acres is None and guntas is None and cents is None and sqft is None and sqyd is None:
        raise ValueError("At least one measurement must be provided.")

    # Resolve to acres first
    if acres is not None:
        a = acres
    elif guntas is not None:
        a = guntas / ACRE_TO_GUNTA
    elif cents is not None:
        a = cents / ACRE_TO_CENT
    elif sqft is not None:
        a = sqft / ACRE_TO_SQFT
    else:
        a = sqyd / ACRE_TO_SQYD

    return {
        'acres': round(a, 4),
        'guntas': round(a * ACRE_TO_GUNTA, 2),
        'cents': round(a * ACRE_TO_CENT, 2),
        'sqft': round(a * ACRE_TO_SQFT, 2),
        'sqyd': round(a * ACRE_TO_SQYD, 2),
    }


def price_per_unit(total_price: float, acres: float) -> dict:
    """
    Given total price (INR) and area in acres,
    compute price per acre, per gunta, per cent, per sqft.
    """
    if acres <= 0:
        raise ValueError("Area must be positive.")
    per_acre = total_price / acres
    return {
        'per_acre': round(per_acre, 2),
        'per_gunta': round(per_acre / ACRE_TO_GUNTA, 2),
        'per_cent': round(per_acre / ACRE_TO_CENT, 2),
        'per_sqft': round(per_acre / ACRE_TO_SQFT, 2),
        'per_sqyd': round(per_acre / ACRE_TO_SQYD, 2),
    }
