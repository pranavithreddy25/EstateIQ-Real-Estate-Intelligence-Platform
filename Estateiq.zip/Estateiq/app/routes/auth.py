import secrets
import time
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db
from app.models import User

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

OTP_TTL_SECONDS = 300
OTP_RESEND_COOLDOWN_SECONDS = 30
OTP_MAX_ATTEMPTS = 5

def normalize_phone(phone):
    return ''.join(character for character in (phone or '') if character.isdigit())[-10:]

def redirect_after_login(user):
    next_page = request.args.get('next') or session.pop('otp_next', None)
    if next_page:
        return redirect(next_page)
    if user.is_admin():
        return redirect(url_for('admin.dashboard'))
    if user.is_agent():
        return redirect(url_for('agent.dashboard'))
    return redirect(url_for('public.index'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('public.index'))

    if request.method == 'POST' and request.form.get('login_method') != 'otp':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            flash(f'Welcome back, {user.full_name}!', 'success')
            
            return redirect_after_login(user)
        else:
            flash('Invalid email address or password.', 'error')

    if request.method == 'POST' and request.form.get('login_method') == 'otp':
        action = request.form.get('otp_action', 'request')
        phone = normalize_phone(request.form.get('phone'))
        user = next((candidate for candidate in User.query.all() if normalize_phone(candidate.phone) == phone), None) if len(phone) == 10 else None

        if not user:
            flash('No account was found for that mobile number.', 'error')
        elif action == 'request':
            last_sent = session.get('otp_sent_at', 0)
            if time.time() - last_sent < OTP_RESEND_COOLDOWN_SECONDS:
                flash('Please wait before requesting another OTP.', 'error')
            else:
                otp = f'{secrets.randbelow(1_000_000):06d}'
                session['otp_phone'] = phone
                session['otp_code'] = otp
                session['otp_sent_at'] = time.time()
                session['otp_attempts'] = 0
                session['otp_next'] = request.args.get('next')
                if current_app.testing or current_app.debug:
                    flash(f'Development OTP: {otp}', 'info')
                else:
                    flash('SMS OTP delivery is not configured yet. Our service will reach you soon.', 'error')
        elif action == 'verify':
            issued_at = session.get('otp_sent_at', 0)
            attempts = session.get('otp_attempts', 0)
            if session.get('otp_phone') != phone or not session.get('otp_code'):
                flash('Request a new OTP first.', 'error')
            elif time.time() - issued_at > OTP_TTL_SECONDS:
                session.pop('otp_code', None)
                flash('This OTP has expired. Request a new one.', 'error')
            elif attempts >= OTP_MAX_ATTEMPTS:
                session.pop('otp_code', None)
                flash('Too many incorrect attempts. Request a new OTP.', 'error')
            elif not secrets.compare_digest(session['otp_code'], request.form.get('otp', '').strip()):
                session['otp_attempts'] = attempts + 1
                flash('Invalid OTP. Please try again.', 'error')
            else:
                session.pop('otp_code', None)
                session.pop('otp_attempts', None)
                login_user(user, remember=True)
                flash(f'Welcome back, {user.full_name}!', 'success')
                return redirect_after_login(user)

    return render_template('auth/login.html', otp_phone=session.get('otp_phone', ''))

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('public.index'))

    if request.method == 'POST':
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        role = request.form.get('role', 'buyer')
        company_name = request.form.get('company_name')

        if User.query.filter_by(email=email).first():
            flash('Email address is already registered. Please sign in.', 'error')
            return redirect(url_for('auth.login'))

        user = User(
            full_name=full_name,
            email=email,
            phone=phone,
            role=role,
            company_name=company_name
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()

        login_user(user)
        flash('Account successfully created!', 'success')
        return redirect(url_for('public.index'))

    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been signed out.', 'info')
    return redirect(url_for('public.index'))
