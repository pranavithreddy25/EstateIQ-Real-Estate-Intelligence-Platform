from flask import Blueprint, render_template, current_app
from app.models import Property, Location
from app.utils.ad_helper import get_active_ad

public_bp = Blueprint('public', __name__)

@public_bp.route('/')
def index():
    # Market Snapshot Statistics
    total_properties = Property.query.count()
    total_locations = Location.query.count()
    
    # Calculate average property value and yield
    all_props = Property.query.all()
    if all_props:
        avg_price = sum(p.price for p in all_props) / len(all_props)
        avg_yield = sum(p.gross_rental_yield for p in all_props) / len(all_props)
    else:
        avg_price = 7800000
        avg_yield = 5.2

    featured_properties = Property.query.filter_by(is_featured=True).limit(6).all()
    top_locations = Location.query.order_by(Location.avg_rental_yield.desc()).limit(4).all()

    # Monetization Banner Ad
    ad_banner = get_active_ad('homepage_banner')

    return render_template('public/index.html',
                           total_properties=total_properties,
                           total_locations=total_locations,
                           avg_price=avg_price,
                           avg_yield=avg_yield,
                           featured_properties=featured_properties,
                           top_locations=top_locations,
                           ad_banner=ad_banner)

@public_bp.route('/insights')
def insights():
    return render_template('public/insights.html')

@public_bp.route('/disclaimer')
def disclaimer():
    return render_template('public/disclaimer.html')

@public_bp.route('/privacy')
def privacy():
    return render_template('public/privacy.html')
