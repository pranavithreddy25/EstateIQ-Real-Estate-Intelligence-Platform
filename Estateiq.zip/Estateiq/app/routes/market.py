from flask import Blueprint, render_template, request, jsonify, url_for
from app.models import Location, PriceHistory, Property

market_bp = Blueprint('market', __name__, url_prefix='/market')

@market_bp.route('/')
def index():
    city = request.args.get('city', 'Hyderabad')
    locations = Location.query.filter_by(town_city=city).order_by(Location.avg_rental_yield.desc()).all()
    location_ids = [location.id for location in locations]
    properties = Property.query.filter(Property.location_id.in_(location_ids)).all() if location_ids else []
    property_data = [{
        'id': property_item.id,
        'title': property_item.title,
        'price': property_item.formatted_price(),
        'latitude': property_item.latitude or property_item.location_rel.latitude,
        'longitude': property_item.longitude or property_item.location_rel.longitude,
        'locality': property_item.location_rel.name if property_item.location_rel else '',
        'url': url_for('properties.detail', property_id=property_item.id)
    } for property_item in properties]
    return render_template(
        'market/index.html',
        locations=locations,
        location_data=[location.to_dict() for location in locations],
        property_data=property_data,
        selected_city=city
    )

@market_bp.route('/locations/<int:location_id>')
def detail(location_id):
    loc = Location.query.get_or_404(location_id)
    history = PriceHistory.query.filter_by(location_id=loc.id).order_by(PriceHistory.year.asc()).all()
    properties = Property.query.filter_by(location_id=loc.id).limit(6).all()
    return render_template('market/detail.html', location=loc, history=history, properties=properties)

@market_bp.route('/compare')
def compare():
    city = request.args.get('city', 'Hyderabad')
    selected_ids = request.args.getlist('loc_ids', type=int)
    
    locations = Location.query.filter_by(town_city=city).all()
    
    if not selected_ids:
        # Default to top 3 locations if none selected
        selected_locations = locations[:3]
    else:
        selected_locations = Location.query.filter(Location.id.in_(selected_ids)).all()

    return render_template('market/compare.html',
                           all_locations=locations,
                           selected_locations=selected_locations)

@market_bp.route('/trends')
def trends():
    city = request.args.get('city', 'Hyderabad')
    locations = Location.query.filter_by(town_city=city).all()
    
    # Format trend chart data
    loc_names = [l.name for l in locations]
    trend_data = {}
    for l in locations:
        hist = PriceHistory.query.filter_by(location_id=l.id).order_by(PriceHistory.year.asc()).all()
        trend_data[l.name] = {
            'years': [h.year for h in hist],
            'prices': [h.avg_price_per_sqft for h in hist],
            'rents': [h.avg_monthly_rent for h in hist]
        }

    return render_template('market/trends.html', locations=locations, trend_data=trend_data)
