from flask import Blueprint, render_template, request, jsonify
from app.analytics.budget_finder import analyze_budget_investment
from app.analytics.calculators import calculate_rental_yield, calculate_emi, calculate_roi, calculate_buy_vs_rent
from app.ml.price_predictor import predictor_engine
from app.models import Location

investment_bp = Blueprint('investment', __name__, url_prefix='/investment')

@investment_bp.route('/budget-analyzer', methods=['GET', 'POST'])
def budget_analyzer():
    if request.method == 'POST':
        budget = float(request.form.get('budget', 8000000))
        purpose = request.form.get('purpose', 'investment')
        city = request.form.get('city', 'Hyderabad')
        property_type = request.form.get('property_type', 'All')
        bedrooms = request.form.get('bedrooms', type=int)
    else:
        budget = float(request.args.get('budget', 8000000))
        purpose = request.args.get('purpose', 'investment')
        city = request.args.get('city', 'Hyderabad')
        property_type = request.args.get('property_type', 'All')
        bedrooms = request.args.get('bedrooms', type=int)

    analysis_result = analyze_budget_investment(
        budget=budget,
        city=city,
        purpose=purpose,
        property_type=property_type,
        bedrooms=bedrooms
    )

    return render_template('investment/budget_analyzer.html', result=analysis_result)

@investment_bp.route('/roi-calculator', methods=['GET', 'POST'])
def roi_calculator():
    price = float(request.args.get('price', 7800000))
    monthly_rent = float(request.args.get('rent', 35000))
    down_payment_pct = float(request.args.get('down_payment_pct', 20))
    interest_rate = float(request.args.get('interest_rate', 8.5))
    appreciation_rate = float(request.args.get('appreciation_rate', 7.5))
    holding_years = int(request.args.get('holding_years', 10))

    yield_res = calculate_rental_yield(price, monthly_rent)
    emi_res = calculate_emi(price * (1 - down_payment_pct / 100.0), interest_rate, tenure_years=20)
    roi_res = calculate_roi(
        purchase_price=price,
        down_payment_pct=down_payment_pct,
        loan_interest_rate=interest_rate,
        initial_monthly_rent=monthly_rent,
        annual_appreciation_pct=appreciation_rate,
        holding_years=holding_years
    )

    return render_template('investment/roi_calculator.html',
                           price=price,
                           monthly_rent=monthly_rent,
                           down_payment_pct=down_payment_pct,
                           interest_rate=interest_rate,
                           appreciation_rate=appreciation_rate,
                           holding_years=holding_years,
                           yield_res=yield_res,
                           emi_res=emi_res,
                           roi_res=roi_res)

@investment_bp.route('/buy-vs-rent')
def buy_vs_rent():
    price = float(request.args.get('price', 8000000))
    rent = float(request.args.get('rent', 32000))
    down_payment_pct = float(request.args.get('down_payment_pct', 20))
    interest_rate = float(request.args.get('interest_rate', 8.5))
    appreciation_pct = float(request.args.get('appreciation_pct', 7.0))
    rent_inflation_pct = float(request.args.get('rent_inflation_pct', 5.0))
    stock_return_pct = float(request.args.get('stock_return_pct', 10.0))
    years = int(request.args.get('years', 10))

    result = calculate_buy_vs_rent(
        property_price=price,
        monthly_rent=rent,
        down_payment_pct=down_payment_pct,
        loan_interest_rate=interest_rate,
        appreciation_pct=appreciation_pct,
        rent_inflation_pct=rent_inflation_pct,
        stock_return_pct=stock_return_pct,
        years=years
    )

    return render_template('investment/buy_vs_rent.html',
                           price=price,
                           rent=rent,
                           down_payment_pct=down_payment_pct,
                           interest_rate=interest_rate,
                           appreciation_pct=appreciation_pct,
                           rent_inflation_pct=rent_inflation_pct,
                           stock_return_pct=stock_return_pct,
                           years=years,
                           result=result)

@investment_bp.route('/valuation', methods=['GET', 'POST'])
def valuation():
    locations = Location.query.all()
    prediction = None

    if request.method == 'POST':
        locality = request.form.get('locality', 'Kokapet')
        property_type = request.form.get('property_type', 'Apartment')
        area_sqft = float(request.form.get('area_sqft', 1650))
        bedrooms = int(request.form.get('bedrooms', 3))
        bathrooms = int(request.form.get('bathrooms', 3))
        age_years = int(request.form.get('age_years', 2))

        prediction = predictor_engine.predict(
            locality=locality,
            property_type=property_type,
            area_sqft=area_sqft,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            age_years=age_years
        )
        prediction['locality'] = locality
        prediction['property_type'] = property_type
        prediction['area_sqft'] = area_sqft

    return render_template('investment/valuation.html', locations=locations, prediction=prediction)


@investment_bp.route('/api/telangana-tax', methods=['POST'])
def api_telangana_tax():
    """API: Calculate official Telangana stamp duty, registration, GST & TDS."""
    from app.analytics.telangana_tax import calculate_telangana_registration_cost
    data = request.get_json(force=True)
    try:
        agreed_price = float(data['agreed_price'])
        govt_market_value = float(data.get('govt_market_value', agreed_price * 0.85))
        property_type = data.get('property_type', 'Apartment')
        status = data.get('status', 'Ready to Move')
        
        breakdown = calculate_telangana_registration_cost(
            agreed_price=agreed_price,
            govt_market_value=govt_market_value,
            property_type=property_type,
            status=status
        )
        return jsonify({
            'status': 'success',
            'tax_breakdown': {
                'agreed_price': breakdown.agreed_price,
                'govt_market_value': breakdown.govt_market_value,
                'taxable_base_value': breakdown.taxable_base_value,
                'stamp_duty': breakdown.stamp_duty,
                'transfer_duty': breakdown.transfer_duty,
                'registration_fee': breakdown.registration_fee,
                'total_registration_charges': breakdown.total_registration_charges,
                'gst_rate_pct': breakdown.gst_rate_pct,
                'gst_amount': breakdown.gst_amount,
                'tds_rate_pct': breakdown.tds_rate_pct,
                'tds_amount': breakdown.tds_amount,
                'total_acquisition_cost': breakdown.total_acquisition_cost
            }
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

