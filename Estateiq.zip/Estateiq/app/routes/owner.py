import os
from uuid import uuid4
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.extensions import db
from app.models import Property, PropertyImage, Location, AgriculturalDetails, AGRICULTURAL_PROPERTY_TYPES
from app.analytics.scoring import compute_investment_score
from app.analytics.agricultural_roi import compute_agricultural_roi, AgriROIInput
from app.utils.decorators import owner_required

owner_bp = Blueprint('owner', __name__, url_prefix='/owner')

@owner_bp.before_request
@login_required
@owner_required
def require_owner():
    pass

def _save_uploaded_images(files):
    image_urls = []
    for image in files:
        if not image or not image.filename:
            continue
        extension = image.filename.rsplit('.', 1)[-1].lower() if '.' in image.filename else ''
        if extension not in current_app.config['ALLOWED_EXTENSIONS']:
            continue
        filename = f"{uuid4().hex}_{secure_filename(image.filename)}"
        image.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
        image_urls.append(url_for('static', filename=f'uploads/{filename}'))
    return image_urls

@owner_bp.route('/submit-property', methods=['GET', 'POST'])
def submit_property():
    locations = Location.query.order_by(Location.district, Location.name).all()
    districts = db.session.query(Location.district).distinct().order_by(Location.district).all()
    districts = [d[0] for d in districts if d[0]]

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        property_type = request.form.get('property_type', 'Apartment')
        purpose = request.form.get('purpose', 'buy')
        location_id = request.form.get('location_id', type=int)
        address = request.form.get('address', '').strip()
        price = float(request.form.get('price', 0))
        description = request.form.get('description', '').strip()
        amenities = request.form.get('amenities', '').strip()
        land_owner_name = request.form.get('land_owner_name', '').strip() or None
        listing_plan = request.form.get('listing_plan', 'free').lower()
        image_urls = [url.strip() for url in request.form.get('image_urls', '').split(',') if url.strip()]
        image_urls = _save_uploaded_images(request.files.getlist('images')) + image_urls

        is_agri = property_type in AGRICULTURAL_PROPERTY_TYPES

        if not title or price <= 0 or not location_id:
            flash('Please complete all required listing fields with valid numbers.', 'error')
            return redirect(url_for('owner.submit_property'))

        loc = Location.query.get(location_id)

        if is_agri:
            acres = float(request.form.get('acres', 0))
            guntas = float(request.form.get('guntas', 0)) if request.form.get('guntas') else (acres * 40.0)
            area_sqft = acres * 43560.0
            price_per_acre = round(price / acres, 2) if acres > 0 else price
            price_per_sqft = round(price / area_sqft, 2) if area_sqft > 0 else 0.0
            survey_number = request.form.get('survey_number', '').strip()
            soil_type = request.form.get('soil_type', 'Red Soil')
            irrigation_source = request.form.get('irrigation_source', 'Borewell')
            road_access = request.form.get('road_access', 'BT Road')
            crop_type = request.form.get('crop_type', '').strip()
            electricity_available = True if request.form.get('electricity_available') else False
            fencing_available = True if request.form.get('fencing_available') else False
            farmhouse_available = True if request.form.get('farmhouse_available') else False
            expected_annual_crop_income = float(request.form.get('expected_annual_crop_income', 0))

            agri_inp = AgriROIInput(
                purchase_price=price,
                land_area_acres=acres,
                annual_crop_income=expected_annual_crop_income,
                location_growth_score=loc.growth_potential_score if loc else 75
            )
            agri_res = compute_agricultural_roi(agri_inp)
            score = agri_res.investment_score
            bedrooms = 0
            bathrooms = 0
            est_monthly_rent = round(expected_annual_crop_income / 12.0)
            gross_yield = round((expected_annual_crop_income / price) * 100.0, 2) if price > 0 else 0.0

        else:
            area_sqft = float(request.form.get('area_sqft', 0))
            if area_sqft <= 0:
                flash('Please enter a valid super area in sq.ft for residential/commercial property.', 'error')
                return redirect(url_for('owner.submit_property'))
            price_per_sqft = round(price / area_sqft, 2)
            bedrooms = int(request.form.get('bedrooms', 2))
            bathrooms = int(request.form.get('bathrooms', 2))
            est_monthly_rent = float(request.form.get('est_monthly_rent', 0))
            gross_yield = round(((est_monthly_rent * 12.0) / price) * 100.0, 2) if price > 0 else 0.0

            score_res = compute_investment_score(
                gross_yield=gross_yield,
                growth_potential_score=loc.growth_potential_score if loc else 80,
                location_quality_score=loc.location_quality_score if loc else 85,
                rental_demand_score=loc.rental_demand_score if loc else 80,
                price=price,
                status="Ready to Move"
            )
            score = score_res['score']
            acres = None
            guntas = None
            price_per_acre = None
            survey_number = None
            soil_type = None
            irrigation_source = None
            road_access = None
            crop_type = None
            electricity_available = None
            fencing_available = None
            farmhouse_available = None
            expected_annual_crop_income = None

        slug = f"prop-{title.lower().replace(' ', '-')[:25]}-{location_id}-{int(price/1000)}"

        prop = Property(
            title=title,
            slug=slug,
            description=description,
            property_type=property_type,
            purpose=purpose,
            location_id=location_id,
            address=address,
            latitude=loc.latitude if loc else 17.3850,
            longitude=loc.longitude if loc else 78.4867,
            price=price,
            area_sqft=area_sqft,
            price_per_sqft=price_per_sqft,
            bedrooms=bedrooms,
            bathrooms=bathrooms,
            est_monthly_rent=est_monthly_rent,
            gross_rental_yield=gross_yield,
            investment_score=score,
            is_verified=False,
            verification_status='Pending',
            is_synthetic=False,
            data_source='Owner Verified Submission',
            user_id=current_user.id,
            contact_person=current_user.full_name,
            land_owner_name=land_owner_name,
            contact_phone=current_user.phone or '+91 99999 99999',
            contact_email=current_user.email,
            amenities=amenities,
            is_featured=listing_plan == 'premium',
            land_area_acres=acres,
            land_area_guntas=guntas,
            price_per_acre=price_per_acre,
            survey_number=survey_number,
            soil_type=soil_type,
            irrigation_source=irrigation_source,
            road_access=road_access,
            crop_type=crop_type,
            electricity_available=electricity_available,
            fencing_available=fencing_available,
            farmhouse_available=farmhouse_available,
            expected_annual_crop_income=expected_annual_crop_income,
            agricultural_investment_score=score if is_agri else None
        )

        db.session.add(prop)
        db.session.flush()

        # Use submitted gallery URLs, or retain a useful category fallback image.
        fallback_url = 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80' if is_agri else 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
        for index, image_url in enumerate(image_urls or [fallback_url]):
            db.session.add(PropertyImage(property_id=prop.id, image_url=image_url, is_primary=index == 0))

        # If agricultural, also create AgriculturalDetails
        if is_agri:
            agri_details = AgriculturalDetails(
                property_id=prop.id,
                acres=acres,
                guntas=guntas,
                cents=round(acres * 100.0, 2),
                total_sqft=area_sqft,
                survey_number=survey_number,
                land_type="Agricultural Patta",
                irrigation_source=irrigation_source,
                road_access=road_access,
                soil_type=soil_type,
                crop_type=crop_type,
                electricity_available=electricity_available,
                fencing_available=fencing_available,
                farmhouse_available=farmhouse_available,
                expected_annual_crop_income=expected_annual_crop_income,
                agricultural_investment_score=score
            )
            db.session.add(agri_details)

        db.session.commit()
        flash('Listing successfully submitted! It is now in the queue for admin verification.', 'success')
        return redirect(url_for('owner.my_listings'))

    return render_template('owner/submit_property.html', locations=locations, districts=districts)

@owner_bp.route('/my-listings')
def my_listings():
    properties = Property.query.filter_by(user_id=current_user.id).order_by(Property.created_at.desc()).all()
    return render_template('owner/listings.html', properties=properties)
