import os
from uuid import uuid4
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.extensions import db
from app.models import Property, Lead, PropertyImage
from app.utils.decorators import agent_required

agent_bp = Blueprint('agent', __name__, url_prefix='/agent')

@agent_bp.before_request
@login_required
@agent_required
def require_agent():
    pass

@agent_bp.route('/dashboard')
def dashboard():
    listings = Property.query.filter_by(user_id=current_user.id).all()
    listing_ids = [p.id for p in listings]
    
    leads = Lead.query.filter(Lead.property_id.in_(listing_ids)).order_by(Lead.created_at.desc()).all() if listing_ids else []

    total_views = sum(p.views_count for p in listings)
    total_saved = sum(p.saved_count for p in listings)

    return render_template('agent/dashboard.html',
                           listings=listings,
                           leads=leads,
                           total_views=total_views,
                           total_saved=total_saved)

@agent_bp.route('/leads/<int:lead_id>/update-status', methods=['POST'])
def update_lead_status(lead_id):
    lead = Lead.query.get_or_404(lead_id)
    new_status = request.form.get('status', 'Contacted')
    lead.status = new_status
    db.session.commit()
    flash('Lead status updated.', 'success')
    return redirect(url_for('agent.dashboard'))

def _save_uploaded_images(files):
    image_urls = []
    for image in files:
        if not image or not image.filename:
            continue
        extension = image.filename.rsplit('.', 1)[-1].lower() if '.' in image.filename else ''
        if extension not in current_app.config['ALLOWED_EXTENSIONS']:
            continue
        filename = f"{uuid4().hex}_{secure_filename(image.filename)}"
        image.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
        image_urls.append(url_for('static', filename=f'uploads/{filename}'))
    return image_urls

@agent_bp.route('/listings/<int:property_id>/edit', methods=['GET', 'POST'])
def edit_listing(property_id):
    listing = Property.query.filter_by(id=property_id, user_id=current_user.id).first_or_404()

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        price = request.form.get('price', type=float)
        if not title or not price or price <= 0:
            flash('Enter a valid title and price.', 'error')
            return redirect(url_for('agent.edit_listing', property_id=listing.id))

        listing.title = title
        listing.price = price
        listing.address = request.form.get('address', '').strip()
        listing.description = request.form.get('description', '').strip()
        listing.land_owner_name = request.form.get('land_owner_name', '').strip() or None
        listing.is_featured = request.form.get('listing_plan') == 'premium'
        if listing.area_sqft:
            listing.price_per_sqft = round(price / listing.area_sqft, 2)
        if listing.land_area_acres and listing.land_area_acres > 0:
            listing.price_per_acre = round(price / listing.land_area_acres, 2)

        image_urls = _save_uploaded_images(request.files.getlist('images')) + [url.strip() for url in request.form.get('image_urls', '').split(',') if url.strip()]
        if image_urls:
            listing.images.clear()
            for index, image_url in enumerate(image_urls):
                listing.images.append(PropertyImage(image_url=image_url, is_primary=index == 0))

        db.session.commit()
        flash('Listing updated successfully.', 'success')
        return redirect(url_for('agent.dashboard'))

    return render_template('agent/edit_listing.html', listing=listing)
