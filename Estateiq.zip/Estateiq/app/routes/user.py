from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import SavedProperty, SavedSearch, Lead

user_bp = Blueprint('user', __name__, url_prefix='/user')

@user_bp.route('/dashboard')
@login_required
def dashboard():
    saved_props = SavedProperty.query.filter_by(user_id=current_user.id).all()
    leads = Lead.query.filter_by(user_id=current_user.id).order_by(Lead.created_at.desc()).all()
    return render_template('dashboard/user_index.html', saved_properties=saved_props, leads=leads)
