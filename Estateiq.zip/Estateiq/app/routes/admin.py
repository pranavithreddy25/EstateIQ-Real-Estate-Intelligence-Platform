from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app.extensions import db
from app.models import Property, User, Lead, Advertisement, Location
from app.utils.decorators import admin_required
from ads.config import AD_SLOTS
from ads import get_manager

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.before_request
@login_required
@admin_required
def require_admin():
    pass


# ─── Dashboard ────────────────────────────────────────────────────────────────

@admin_bp.route('/dashboard')
def dashboard():
    total_users = User.query.count()
    total_properties = Property.query.count()
    pending_verifications = Property.query.filter_by(verification_status='Pending').count()
    total_leads = Lead.query.count()
    total_ads = Advertisement.query.count()
    active_ads = Advertisement.query.filter_by(is_active=True).count()

    properties = Property.query.order_by(Property.created_at.desc()).limit(10).all()
    users = User.query.order_by(User.created_at.desc()).limit(10).all()

    return render_template('admin/dashboard.html',
                           total_users=total_users,
                           total_properties=total_properties,
                           pending_verifications=pending_verifications,
                           total_leads=total_leads,
                           total_ads=total_ads,
                           active_ads=active_ads,
                           properties=properties,
                           users=users)


# ─── Property Verification ───────────────────────────────────────────────────

@admin_bp.route('/verification')
def verification_queue():
    pending = Property.query.filter_by(verification_status='Pending').all()
    return render_template('admin/verification.html', pending_properties=pending)

@admin_bp.route('/properties/<int:property_id>/verify', methods=['POST'])
def verify_property(property_id):
    action = request.form.get('action')
    prop = Property.query.get_or_404(property_id)
    reason = request.form.get('rejection_reason', '')

    if action == 'approve':
        prop.is_verified = True
        prop.verification_status = 'Verified'
        prop.rejection_reason = None
        flash(f'Property #{prop.id} approved and marked as Verified.', 'success')
    elif action == 'reject':
        prop.is_verified = False
        prop.verification_status = 'Rejected'
        prop.rejection_reason = reason
        flash(f'Property #{prop.id} rejected.', 'info')

    db.session.commit()
    return redirect(url_for('admin.verification_queue'))


# ─── Price Management ─────────────────────────────────────────────────────────

@admin_bp.route('/prices')
def price_management():
    """Admin: View and edit market price benchmarks by location."""
    locations = Location.query.order_by(Location.district, Location.mandal, Location.name).all()
    districts = db.session.query(Location.district).distinct().order_by(Location.district).all()
    districts = [d[0] for d in districts if d[0]]

    filter_district = request.args.get('district', '')
    if filter_district:
        locations = Location.query.filter(
            Location.district == filter_district
        ).order_by(Location.mandal, Location.name).all()

    return render_template('admin/price_management.html',
                           locations=locations,
                           districts=districts,
                           filter_district=filter_district)

@admin_bp.route('/prices/<int:location_id>/edit', methods=['GET', 'POST'])
def edit_location_price(location_id):
    """Admin: Edit avg price per sqft, price per acre, rental yield, appreciation for a locality."""
    loc = Location.query.get_or_404(location_id)

    if request.method == 'POST':
        try:
            loc.avg_price_per_sqft = float(request.form.get('avg_price_per_sqft', loc.avg_price_per_sqft))
            loc.avg_price_per_acre = float(request.form.get('avg_price_per_acre', loc.avg_price_per_acre))
            loc.avg_monthly_rent = float(request.form.get('avg_monthly_rent', loc.avg_monthly_rent))
            loc.avg_rental_yield = float(request.form.get('avg_rental_yield', loc.avg_rental_yield))
            loc.annual_appreciation_rate = float(request.form.get('annual_appreciation_rate', loc.annual_appreciation_rate))
            loc.growth_potential_score = int(request.form.get('growth_potential_score', loc.growth_potential_score))
            loc.location_quality_score = int(request.form.get('location_quality_score', loc.location_quality_score))
            loc.rental_demand_score = int(request.form.get('rental_demand_score', loc.rental_demand_score))
            db.session.commit()
            flash(f'Market data for {loc.name} updated successfully.', 'success')
            return redirect(url_for('admin.price_management', district=loc.district))
        except ValueError as e:
            flash(f'Invalid value: {str(e)}', 'error')

    return render_template('admin/edit_location_price.html', location=loc)

@admin_bp.route('/prices/property/<int:property_id>/edit', methods=['GET', 'POST'])
def edit_property_price(property_id):
    """Admin: Directly edit a specific property's price, rent, and investment score."""
    prop = Property.query.get_or_404(property_id)

    if request.method == 'POST':
        try:
            prop.price = float(request.form.get('price', prop.price))
            prop.area_sqft = float(request.form.get('area_sqft', prop.area_sqft))
            prop.price_per_sqft = round(prop.price / prop.area_sqft, 2) if prop.area_sqft else prop.price_per_sqft
            prop.est_monthly_rent = float(request.form.get('est_monthly_rent', prop.est_monthly_rent))
            prop.gross_rental_yield = round((prop.est_monthly_rent * 12 / prop.price) * 100, 2) if prop.price else 0
            prop.investment_score = int(request.form.get('investment_score', prop.investment_score))
            prop.is_featured = request.form.get('is_featured') == 'on'
            prop.verification_status = request.form.get('verification_status', prop.verification_status)
            prop.is_verified = (prop.verification_status == 'Verified')
            db.session.commit()
            flash(f'Property #{prop.id} "{prop.title}" updated.', 'success')
            return redirect(url_for('admin.dashboard'))
        except ValueError as e:
            flash(f'Invalid value: {str(e)}', 'error')

    return render_template('admin/edit_property_price.html', property=prop)

@admin_bp.route('/api/prices/bulk-update', methods=['POST'])
def api_bulk_price_update():
    """Admin API: Bulk update avg_price_per_sqft for a district."""
    data = request.get_json(force=True)
    district = data.get('district')
    multiplier = float(data.get('multiplier', 1.0))

    if not district or multiplier <= 0:
        return jsonify({'status': 'error', 'message': 'Invalid district or multiplier'}), 400

    locations = Location.query.filter(Location.district == district).all()
    for loc in locations:
        loc.avg_price_per_sqft = round(loc.avg_price_per_sqft * multiplier, 2)
        if loc.avg_price_per_acre:
            loc.avg_price_per_acre = round(loc.avg_price_per_acre * multiplier, 2)
        loc.avg_monthly_rent = round(loc.avg_monthly_rent * multiplier, 2)

    db.session.commit()
    return jsonify({'status': 'success', 'updated': len(locations), 'district': district})


# ─── Advertisement Management ────────────────────────────────────────────────

@admin_bp.route('/advertisements')
def advertisements():
    ads = Advertisement.query.order_by(Advertisement.created_at.desc()).all()
    mgr = get_manager()
    slots = mgr.get_all_slots() if mgr else []
    return render_template('admin/advertisements.html', advertisements=ads, slots=slots)

@admin_bp.route('/advertisements/create', methods=['GET', 'POST'])
def create_advertisement():
    """Admin: Create a new direct advertisement record."""
    if request.method == 'POST':
        ad = Advertisement(
            slot_type=request.form.get('slot_type', 'listing_inline'),
            advertiser_name=request.form.get('advertiser_name', ''),
            title=request.form.get('title', ''),
            description=request.form.get('description', ''),
            target_url=request.form.get('target_url', '#'),
            image_url=request.form.get('image_url', ''),
            is_active=request.form.get('is_active') == 'on'
        )
        db.session.add(ad)
        db.session.commit()
        flash(f'Advertisement "{ad.title}" created successfully.', 'success')
        return redirect(url_for('admin.advertisements'))
    return render_template('admin/create_advertisement.html')

@admin_bp.route('/advertisements/<int:ad_id>/edit', methods=['GET', 'POST'])
def edit_advertisement(ad_id):
    """Admin: Edit an existing advertisement."""
    ad = Advertisement.query.get_or_404(ad_id)

    if request.method == 'POST':
        ad.advertiser_name = request.form.get('advertiser_name', ad.advertiser_name)
        ad.title = request.form.get('title', ad.title)
        ad.description = request.form.get('description', ad.description)
        ad.target_url = request.form.get('target_url', ad.target_url)
        ad.image_url = request.form.get('image_url', ad.image_url)
        ad.slot_type = request.form.get('slot_type', ad.slot_type)
        ad.is_active = request.form.get('is_active') == 'on'
        db.session.commit()
        flash(f'Advertisement "{ad.title}" updated.', 'success')
        return redirect(url_for('admin.advertisements'))

    return render_template('admin/edit_advertisement.html', ad=ad)

@admin_bp.route('/advertisements/<int:ad_id>/delete', methods=['POST'])
def delete_advertisement(ad_id):
    ad = Advertisement.query.get_or_404(ad_id)
    title = ad.title
    db.session.delete(ad)
    db.session.commit()
    flash(f'Advertisement "{title}" deleted.', 'info')
    return redirect(url_for('admin.advertisements'))

@admin_bp.route('/advertisements/toggle-slot', methods=['POST'])
def toggle_ad_slot():
    """Admin: Toggle a Google AdSense slot on/off globally."""
    slot_id = request.form.get('slot_id')
    enable = request.form.get('enable') == 'true'
    mgr = get_manager()
    if mgr and slot_id in AD_SLOTS:
        if enable:
            mgr.enable_slot(slot_id)
            flash(f"Ad slot '{slot_id}' enabled.", 'success')
        else:
            mgr.disable_slot(slot_id)
            flash(f"Ad slot '{slot_id}' disabled.", 'info')
    return redirect(url_for('admin.advertisements'))
