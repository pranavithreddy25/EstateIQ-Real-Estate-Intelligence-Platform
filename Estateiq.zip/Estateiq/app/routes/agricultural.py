from flask import Blueprint, render_template, request, jsonify
from app.analytics.land_converter import normalize_to_standard, price_per_unit, convert_land_area
from app.analytics.agricultural_roi import compute_agricultural_roi, compare_agri_vs_residential, AgriROIInput
from app.models import Property, Location
from app.extensions import db

agricultural_bp = Blueprint('agricultural', __name__, url_prefix='/agricultural')

AGRICULTURAL_TYPES = [
    'Agricultural Land', 'Farm Land', 'Orchard', 'Plantation Land',
    'Farm House Land', 'Agricultural Plot'
]


@agricultural_bp.route('/')
def index():
    """Agricultural Land Discovery & Search."""
    district = request.args.get('district')
    mandal = request.args.get('mandal')
    min_acres = request.args.get('min_acres', type=float)
    max_acres = request.args.get('max_acres', type=float)
    soil_type = request.args.get('soil_type')
    irrigation = request.args.get('irrigation')
    road_access = request.args.get('road_access')
    sort_by = request.args.get('sort_by', 'investment_score')

    query = Property.query.join(Location).filter(
        Property.property_type.in_(AGRICULTURAL_TYPES)
    )

    if district:
        query = query.filter(Location.district == district)
    if mandal:
        query = query.filter(Location.mandal == mandal)
    if min_acres:
        query = query.filter(Property.land_area_acres >= min_acres)
    if max_acres:
        query = query.filter(Property.land_area_acres <= max_acres)
    if soil_type:
        query = query.filter(Property.soil_type == soil_type)
    if irrigation:
        query = query.filter(Property.irrigation_source == irrigation)
    if road_access:
        query = query.filter(Property.road_access == road_access)

    if sort_by == 'price_low':
        query = query.order_by(Property.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Property.price.desc())
    elif sort_by == 'acres_high':
        query = query.order_by(Property.land_area_acres.desc())
    else:
        query = query.order_by(Property.investment_score.desc())

    properties = query.limit(50).all()

    # District list for filter dropdown
    districts = db.session.query(Location.district).distinct().order_by(Location.district).all()
    districts = [d[0] for d in districts if d[0]]

    return render_template('agricultural/index.html',
                           properties=properties,
                           districts=districts,
                           selected_district=district,
                           selected_mandal=mandal,
                           min_acres=min_acres,
                           max_acres=max_acres,
                           sort_by=sort_by)


@agricultural_bp.route('/roi-calculator')
def roi_calculator():
    """Agricultural ROI & Scenario Simulator."""
    return render_template('agricultural/roi_calculator.html')


@agricultural_bp.route('/api/calculate-roi', methods=['POST'])
def api_calculate_roi():
    """API: Compute Agricultural ROI for given parameters."""
    data = request.get_json(force=True)
    try:
        inp = AgriROIInput(
            purchase_price=float(data['purchase_price']),
            land_area_acres=float(data['land_area_acres']),
            annual_crop_income=float(data.get('annual_crop_income', 0)),
            annual_expenses=float(data.get('annual_expenses', 0)),
            holding_years=int(data.get('holding_years', 10)),
            conservative_appreciation=float(data.get('conservative_appreciation', 5)),
            moderate_appreciation=float(data.get('moderate_appreciation', 9)),
            optimistic_appreciation=float(data.get('optimistic_appreciation', 14)),
            water_score=int(data.get('water_score', 50)),
            road_score=int(data.get('road_score', 50)),
            location_growth_score=int(data.get('location_growth_score', 50)),
            income_potential_score=int(data.get('income_potential_score', 50)),
            development_score=int(data.get('development_score', 50)),
        )
        result = compute_agricultural_roi(inp)
        return jsonify({
            'status': 'success',
            'investment_score': result.investment_score,
            'price_per_acre': result.price_per_acre,
            'score_breakdown': result.score_breakdown,
            'conservative': {
                'final_land_value': result.conservative.final_land_value,
                'total_crop_income': result.conservative.total_crop_income,
                'total_expenses': result.conservative.total_expenses,
                'net_profit': result.conservative.net_profit,
                'roi_percent': result.conservative.roi_percent,
                'cagr_percent': result.conservative.cagr_percent,
                'annual_breakdown': result.conservative.annual_breakdown,
            },
            'moderate': {
                'final_land_value': result.moderate.final_land_value,
                'total_crop_income': result.moderate.total_crop_income,
                'total_expenses': result.moderate.total_expenses,
                'net_profit': result.moderate.net_profit,
                'roi_percent': result.moderate.roi_percent,
                'cagr_percent': result.moderate.cagr_percent,
                'annual_breakdown': result.moderate.annual_breakdown,
            },
            'optimistic': {
                'final_land_value': result.optimistic.final_land_value,
                'total_crop_income': result.optimistic.total_crop_income,
                'total_expenses': result.optimistic.total_expenses,
                'net_profit': result.optimistic.net_profit,
                'roi_percent': result.optimistic.roi_percent,
                'cagr_percent': result.optimistic.cagr_percent,
                'annual_breakdown': result.optimistic.annual_breakdown,
            },
        })
    except (KeyError, ValueError, TypeError) as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400


@agricultural_bp.route('/unit-converter')
def unit_converter():
    """Interactive Land Area Unit Converter."""
    return render_template('agricultural/unit_converter.html')


@agricultural_bp.route('/api/convert-units', methods=['POST'])
def api_convert_units():
    """API: Convert land area between units."""
    data = request.get_json(force=True)
    try:
        value = float(data['value'])
        from_unit = data['from_unit']
        result = normalize_to_standard(**{from_unit.lower().replace('.', '').replace(' ', '_'): value})
        return jsonify({'status': 'success', 'result': result})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400


@agricultural_bp.route('/compare')
def compare():
    """Agricultural vs Residential Investment Comparator."""
    return render_template('agricultural/compare.html')


@agricultural_bp.route('/api/compare', methods=['POST'])
def api_compare():
    """API: Agricultural vs Residential comparison."""
    data = request.get_json(force=True)
    try:
        result = compare_agri_vs_residential(
            agri_purchase_price=float(data['agri_purchase_price']),
            agri_appreciation_pct=float(data.get('agri_appreciation_pct', 9)),
            agri_annual_income=float(data.get('agri_annual_income', 0)),
            resi_purchase_price=float(data.get('resi_purchase_price', data['agri_purchase_price'])),
            resi_appreciation_pct=float(data.get('resi_appreciation_pct', 7.5)),
            resi_monthly_rent=float(data.get('resi_monthly_rent', 0)),
            holding_years=int(data.get('holding_years', 10)),
        )
        return jsonify({'status': 'success', 'result': result})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400
