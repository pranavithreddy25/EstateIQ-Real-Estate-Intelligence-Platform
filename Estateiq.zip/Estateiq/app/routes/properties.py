from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import current_user
from app.extensions import db
from app.models import Property, Location, PropertyImage, Lead, PropertyView, SavedProperty
from app.analytics.scoring import compute_investment_score
from app.analytics.calculators import calculate_emi, calculate_roi
from app.utils.seo import generate_property_jsonld
from app.utils.ad_helper import get_active_ad

properties_bp = Blueprint('properties', __name__, url_prefix='/properties')

@properties_bp.route('/')
def index():
    # Filter Parameters
    district = request.args.get('district', 'Hyderabad')
    mandal = request.args.get('mandal')
    locality_id = request.args.get('locality_id', type=int)
    property_type = request.args.get('property_type')
    purpose = request.args.get('purpose')  # buy, rent, investment
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    bedrooms = request.args.get('bedrooms', type=int)
    min_yield = request.args.get('min_yield', type=float)
    min_score = request.args.get('min_score', type=int)
    sort_by = request.args.get('sort_by', 'investment_score')

    # Exclude agricultural types from main property search
    AGRI_TYPES = ['Agricultural Land', 'Farm Land', 'Orchard', 'Plantation Land', 'Farm House Land', 'Agricultural Plot']
    query = Property.query.join(Location).filter(
        Location.district == district,
        ~Property.property_type.in_(AGRI_TYPES)
    )

    if locality_id:
        query = query.filter(Property.location_id == locality_id)
    if mandal:
        query = query.filter(Location.mandal == mandal)
    if property_type and property_type != 'All':
        query = query.filter(Property.property_type == property_type)
    if purpose and purpose != 'All':
        query = query.filter(Property.purpose == purpose)
    if min_price:
        query = query.filter(Property.price >= min_price)
    if max_price:
        query = query.filter(Property.price <= max_price)
    if bedrooms:
        query = query.filter(Property.bedrooms == bedrooms)
    if min_yield:
        query = query.filter(Property.gross_rental_yield >= min_yield)
    if min_score:
        query = query.filter(Property.investment_score >= min_score)

    # Sorting
    if sort_by == 'price_low':
        query = query.order_by(Property.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Property.price.desc())
    elif sort_by == 'yield':
        query = query.order_by(Property.gross_rental_yield.desc())
    else:
        query = query.order_by(Property.investment_score.desc())

    properties = query.all()
    locations = Location.query.filter(Location.district == district).all()
    districts = [row[0] for row in db.session.query(Location.district).distinct().order_by(Location.district).all() if row[0]]
    premium_properties = [property_item for property_item in properties if property_item.is_featured]
    free_properties = [property_item for property_item in properties if not property_item.is_featured]
    ad_inline = get_active_ad('listing_inline')

    return render_template('properties/index.html',
                           properties=properties,
                           premium_properties=premium_properties,
                           free_properties=free_properties,
                           locations=locations,
                           districts=districts,
                           selected_district=district,
                           selected_mandal=mandal,
                           selected_locality=locality_id,
                           selected_type=property_type,
                           selected_purpose=purpose,
                           min_price=min_price,
                           max_price=max_price,
                           bedrooms=bedrooms,
                           min_yield=min_yield,
                           min_score=min_score,
                           sort_by=sort_by,
                           ad_inline=ad_inline)

@properties_bp.route('/<int:property_id>')
def detail(property_id):
    prop = Property.query.get_or_404(property_id)

    # Track View
    try:
        prop.views_count += 1
        p_view = PropertyView(property_id=prop.id, ip_address=request.remote_addr, user_agent=request.headers.get('User-Agent'))
        db.session.add(p_view)
        db.session.commit()
    except Exception:
        db.session.rollback()

    # Calculations
    emi_info = calculate_emi(principal=prop.price * 0.8)
    roi_info = calculate_roi(
        purchase_price=prop.price,
        down_payment_pct=20,
        initial_monthly_rent=prop.est_monthly_rent,
        annual_appreciation_pct=prop.location_rel.annual_appreciation_rate if prop.location_rel else 7.5,
        holding_years=10
    )

    # Score detail
    score_details = compute_investment_score(
        gross_yield=prop.gross_rental_yield,
        growth_potential_score=prop.location_rel.growth_potential_score if prop.location_rel else 80,
        location_quality_score=prop.location_rel.location_quality_score if prop.location_rel else 85,
        rental_demand_score=prop.location_rel.rental_demand_score if prop.location_rel else 80,
        price=prop.price,
        age_years=prop.age_years,
        status=prop.status
    )

    # Similar Properties
    similar_properties = Property.query.filter(
        Property.location_id == prop.location_id,
        Property.id != prop.id
    ).limit(3).all()

    # Check if saved
    is_saved = False
    if current_user.is_authenticated:
        is_saved = SavedProperty.query.filter_by(user_id=current_user.id, property_id=prop.id).first() is not None

    json_ld = generate_property_jsonld(prop)
    ad_detail = get_active_ad('property_detail')

    return render_template('properties/detail.html',
                           property=prop,
                           emi_info=emi_info,
                           roi_info=roi_info,
                           score_details=score_details,
                           similar_properties=similar_properties,
                           is_saved=is_saved,
                           json_ld=json_ld,
                           ad_detail=ad_detail)

@properties_bp.route('/<int:property_id>/inquire', methods=['POST'])
def submit_lead(property_id):
    prop = Property.query.get_or_404(property_id)

    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    message = request.form.get('message')
    preferred_time = request.form.get('preferred_time', 'Anytime')

    if not name or not email or not phone:
        flash('Please fill in your name, email, and phone number.', 'error')
        return redirect(url_for('properties.detail', property_id=property_id))

    lead = Lead(
        property_id=prop.id,
        user_id=current_user.id if current_user.is_authenticated else None,
        sender_name=name,
        sender_email=email,
        sender_phone=phone,
        message=message,
        preferred_contact_time=preferred_time,
        status='New'
    )
    
    try:
        prop.leads_count += 1
        db.session.add(lead)
        db.session.commit()
        flash('Thank you! Your inquiry has been sent directly to the verified listing representative.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred submitting your lead. Please try again.', 'error')

    return redirect(url_for('properties.detail', property_id=property_id))

@properties_bp.route('/<int:property_id>/save', methods=['POST'])
def toggle_save(property_id):
    if not current_user.is_authenticated:
        return jsonify({'status': 'error', 'message': 'Authentication required'}), 401

    existing = SavedProperty.query.filter_by(user_id=current_user.id, property_id=property_id).first()
    prop = Property.query.get(property_id)

    if existing:
        db.session.delete(existing)
        if prop and prop.saved_count > 0:
            prop.saved_count -= 1
        saved = False
    else:
        new_save = SavedProperty(user_id=current_user.id, property_id=property_id)
        db.session.add(new_save)
        if prop:
            prop.saved_count += 1
        saved = True

    db.session.commit()
    return jsonify({'status': 'success', 'saved': saved})

@properties_bp.route('/api/map-data')
def api_map_data():
    district = request.args.get('district', 'Hyderabad')
    properties = Property.query.join(Location).filter(Location.district == district).all()

    markers = []
    for p in properties:
        markers.append({
            'id': p.id,
            'title': p.title,
            'price_formatted': p.formatted_price(),
            'locality': p.location_rel.name if p.location_rel else '',
            'district': p.location_rel.district if p.location_rel else '',
            'mandal': p.location_rel.mandal if p.location_rel else '',
            'bedrooms': p.bedrooms,
            'gross_yield': p.gross_rental_yield,
            'investment_score': p.investment_score,
            'latitude': p.latitude,
            'longitude': p.longitude,
            'url': url_for('properties.detail', property_id=p.id)
        })

    return jsonify({'district': district, 'markers': markers})
