from flask import Blueprint, render_template, request, jsonify, abort
from app.models import Location, Property
from app.extensions import db
from sqlalchemy import func
import json

locations_bp = Blueprint('locations', __name__)


def slugify(text):
    if not text:
        return ''
    return text.lower().replace('–', '-').replace(' ', '-').replace('_', '-')


# ─── Dependent Dropdown APIs ───────────────────────────────────────────────────

@locations_bp.route('/api/locations/districts')
def api_districts():
    """Return all unique districts in Telangana."""
    rows = db.session.query(Location.district).distinct().order_by(Location.district).all()
    districts = [r[0] for r in rows if r[0]]
    return jsonify({'districts': districts})


@locations_bp.route('/api/locations/mandals')
def api_mandals():
    """Return mandals for a given district."""
    district = request.args.get('district', '').strip()
    if not district:
        return jsonify({'mandals': []})
    rows = db.session.query(Location.mandal).filter(
        func.lower(Location.district) == district.lower(),
        Location.mandal != None,
        Location.mandal != ''
    ).distinct().order_by(Location.mandal).all()
    mandals = [r[0] for r in rows if r[0]]
    return jsonify({'mandals': mandals})


@locations_bp.route('/api/locations/localities')
def api_localities():
    """Return localities for a given mandal or district."""
    mandal = request.args.get('mandal', '').strip()
    district = request.args.get('district', '').strip()
    query = db.session.query(Location.locality_village, Location.id, Location.name)
    if mandal:
        query = query.filter(func.lower(Location.mandal) == mandal.lower())
    if district:
        query = query.filter(func.lower(Location.district) == district.lower())
    query = query.order_by(Location.name)
    rows = query.all()
    localities = [
        {'id': r.id, 'name': r.locality_village or r.name}
        for r in rows if r.locality_village or r.name
    ]
    return jsonify({'localities': localities})


@locations_bp.route('/api/locations/search')
def api_location_search():
    """Full-text location search across district, mandal, locality."""
    q = request.args.get('q', '').strip()
    if len(q) < 2:
        return jsonify({'results': []})
    pattern = f'%{q}%'
    rows = Location.query.filter(
        db.or_(
            Location.name.ilike(pattern),
            Location.district.ilike(pattern),
            Location.mandal.ilike(pattern),
            Location.locality_village.ilike(pattern),
            Location.town_city.ilike(pattern),
        )
    ).limit(15).all()
    results = [loc.to_dict() for loc in rows]
    return jsonify({'results': results})


# ─── SEO Telangana Hub ─────────────────────────────────────────────────────────

@locations_bp.route('/telangana')
def telangana_hub():
    """Telangana State Real Estate Intelligence Hub."""
    districts = db.session.query(
        Location.district,
        func.count(Property.id).label('property_count'),
        func.avg(Location.avg_price_per_sqft).label('avg_psf'),
        func.avg(Location.avg_price_per_acre).label('avg_acre'),
        func.avg(Location.annual_appreciation_rate).label('avg_appr'),
    ).outerjoin(Property, Property.location_id == Location.id).group_by(
        Location.district
    ).order_by(Location.district).all()

    # JSON-LD Schema for Telangana State Hub
    jsonld = {
        "@context": "https://schema.org",
        "@type": "Place",
        "name": "Telangana Real Estate Market",
        "description": "Comprehensive statewide real estate and agricultural land market intelligence for all 33 Telangana districts.",
        "containedInPlace": {
            "@type": "Country",
            "name": "India"
        }
    }

    return render_template('locations/telangana.html', districts=districts, jsonld=json.dumps(jsonld), slugify=slugify)


@locations_bp.route('/telangana/<district_slug>')
def district_hub(district_slug):
    """District-level Real Estate Intelligence Page."""
    clean_slug = district_slug.lower().replace('-', ' ')
    loc = Location.query.filter(
        func.lower(Location.district) == clean_slug
    ).first()

    if not loc:
        # Try substring or relaxed match
        loc = Location.query.filter(
            func.replace(func.lower(Location.district), '-', ' ') == clean_slug
        ).first()

    if not loc:
        abort(404)

    district_name = loc.district

    mandals = db.session.query(
        Location.mandal,
        func.count(Property.id).label('property_count'),
        func.avg(Location.avg_price_per_sqft).label('avg_psf'),
        func.avg(Location.avg_price_per_acre).label('avg_acre'),
        func.avg(Location.annual_appreciation_rate).label('avg_appr')
    ).outerjoin(Property, Property.location_id == Location.id).filter(
        Location.district == district_name,
        Location.mandal != None,
        Location.mandal != ''
    ).group_by(Location.mandal).order_by(Location.mandal).all()

    properties = Property.query.join(Location).filter(
        Location.district == district_name
    ).order_by(Property.investment_score.desc()).limit(18).all()

    jsonld = {
        "@context": "https://schema.org",
        "@type": "Place",
        "name": f"{district_name} District Real Estate",
        "description": f"Real estate intelligence, pricing trends, and property listings in {district_name} District, Telangana.",
        "address": {
            "@type": "PostalAddress",
            "addressRegion": "Telangana",
            "addressCountry": "IN"
        }
    }

    return render_template('locations/district.html',
                           district=district_name,
                           district_slug=district_slug,
                           mandals=mandals,
                           properties=properties,
                           sample_loc=loc,
                           jsonld=json.dumps(jsonld),
                           slugify=slugify)


@locations_bp.route('/telangana/<district_slug>/<mandal_slug>')
def mandal_hub(district_slug, mandal_slug):
    """Mandal-level Real Estate Intelligence Page."""
    clean_dist = district_slug.lower().replace('-', ' ')
    clean_mandal = mandal_slug.lower().replace('-', ' ')

    loc = Location.query.filter(
        func.replace(func.lower(Location.district), '-', ' ') == clean_dist,
        func.replace(func.lower(Location.mandal), '-', ' ') == clean_mandal
    ).first()

    if not loc:
        abort(404)

    district_name = loc.district
    mandal_name = loc.mandal

    localities = Location.query.filter_by(
        district=district_name,
        mandal=mandal_name
    ).all()

    properties = Property.query.join(Location).filter(
        Location.district == district_name,
        Location.mandal == mandal_name
    ).order_by(Property.investment_score.desc()).limit(24).all()

    jsonld = {
        "@context": "https://schema.org",
        "@type": "Place",
        "name": f"{mandal_name} Mandal Real Estate, {district_name}",
        "description": f"Property price valuation, rental yield analysis, and active listings in {mandal_name} Mandal.",
        "address": {
            "@type": "PostalAddress",
            "addressLocality": mandal_name,
            "addressRegion": district_name,
            "addressCountry": "IN"
        }
    }

    return render_template('locations/mandal.html',
                           district=district_name,
                           district_slug=district_slug,
                           mandal=mandal_name,
                           mandal_slug=mandal_slug,
                           location=loc,
                           localities=localities,
                           properties=properties,
                           jsonld=json.dumps(jsonld),
                           slugify=slugify)
