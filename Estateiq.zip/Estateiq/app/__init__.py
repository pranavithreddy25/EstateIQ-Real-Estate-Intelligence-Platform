import os
from flask import Flask, render_template
from sqlalchemy import inspect, text
from config import config
from app.extensions import db, login_manager, csrf
from app.utils.formatters import format_currency, format_number


def create_app(config_name='default'):
    app = Flask(__name__,
                template_folder=os.path.join(os.path.dirname(__file__), 'templates'),
                static_folder=os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static'))

    app.config.from_object(config[config_name])
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Initialize Extensions
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    # Initialize Ads Module (fully optional — disabled by default)
    try:
        from ads import init_ads
        init_ads(app)
    except ImportError:
        pass

    # Context Processors & Template Filters
    @app.context_processor
    def inject_globals():
        return {
            'config': app.config,
            'BRAND_NAME': app.config.get('BRAND_NAME', 'Estate IQ'),
            'BRAND_TAGLINE': app.config.get('BRAND_TAGLINE', ''),
            'ADS_ENABLED': app.config.get('ADS_ENABLED', False),
        }

    app.jinja_env.filters['currency'] = format_currency
    app.jinja_env.filters['number'] = format_number

    # Register Blueprints — existing
    from app.routes.public import public_bp
    from app.routes.auth import auth_bp
    from app.routes.properties import properties_bp
    from app.routes.investment import investment_bp
    from app.routes.market import market_bp
    from app.routes.user import user_bp
    from app.routes.owner import owner_bp
    from app.routes.agent import agent_bp
    from app.routes.admin import admin_bp

    # Register Blueprints — new
    from app.routes.agricultural import agricultural_bp
    from app.routes.locations import locations_bp

    # Keep existing SQLite development databases compatible with additive model fields.
    with app.app_context():
        inspector = inspect(db.engine)
        if 'properties' in inspector.get_table_names():
            property_columns = {column['name'] for column in inspector.get_columns('properties')}
            if 'land_owner_name' not in property_columns:
                db.session.execute(text('ALTER TABLE properties ADD COLUMN land_owner_name VARCHAR(100)'))
                db.session.commit()

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(properties_bp)
    app.register_blueprint(investment_bp)
    app.register_blueprint(market_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(owner_bp)
    app.register_blueprint(agent_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(agricultural_bp)
    app.register_blueprint(locations_bp)

    # Custom Error Handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    return app
