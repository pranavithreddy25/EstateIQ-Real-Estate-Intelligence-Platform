from datetime import datetime
from app.extensions import db
from app.utils.formatters import format_currency, format_number

class Property(db.Model):
    __tablename__ = 'properties'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(220), unique=True, index=True)
    description = db.Column(db.Text, nullable=True)

    # Classification
    property_type = db.Column(db.String(50), nullable=False, index=True)
    # Types: Apartment, Villa, Independent House, Plot, Commercial, Agricultural Land,
    #        Farm Land, Orchard, Plantation Land, Farm House Land, Agricultural Plot
    purpose = db.Column(db.String(20), nullable=False, default='buy', index=True)  # buy, rent, investment
    status = db.Column(db.String(30), default='Ready to Move')  # Ready to Move, Under Construction

    # Location
    location_id = db.Column(db.Integer, db.ForeignKey('locations.id'), nullable=False, index=True)
    address = db.Column(db.String(255), nullable=True)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)

    # Financials & Specifications (for residential/commercial)
    price = db.Column(db.Float, nullable=False, index=True)  # in INR
    area_sqft = db.Column(db.Float, nullable=False, index=True)
    price_per_sqft = db.Column(db.Float, nullable=False)
    bedrooms = db.Column(db.Integer, default=2, index=True)
    bathrooms = db.Column(db.Integer, default=2)
    balconies = db.Column(db.Integer, default=1)
    floor_number = db.Column(db.Integer, default=3)
    total_floors = db.Column(db.Integer, default=10)
    age_years = db.Column(db.Integer, default=2)
    facing = db.Column(db.String(30), default='East')
    parking_spaces = db.Column(db.Integer, default=1)

    # Agricultural Land Fields
    land_area_acres = db.Column(db.Float, nullable=True)          # e.g. 2.5 Acres
    land_area_guntas = db.Column(db.Float, nullable=True)         # e.g. 100 Guntas
    land_area_cents = db.Column(db.Float, nullable=True)          # e.g. 250 Cents
    price_per_acre = db.Column(db.Float, nullable=True)           # in INR
    survey_number = db.Column(db.String(50), nullable=True)
    soil_type = db.Column(db.String(50), nullable=True)           # Red, Black, Sandy, Loam, Clay
    irrigation_source = db.Column(db.String(50), nullable=True)  # Borewell, Canal, Rainfed, River, Tank
    road_access = db.Column(db.String(50), nullable=True)         # BT Road, Tar Road, Mud Road, No Road
    crop_type = db.Column(db.String(100), nullable=True)          # Paddy, Cotton, Maize, Turmeric, etc.
    electricity_available = db.Column(db.Boolean, nullable=True)
    fencing_available = db.Column(db.Boolean, nullable=True)
    farmhouse_available = db.Column(db.Boolean, nullable=True)
    expected_annual_crop_income = db.Column(db.Float, nullable=True)  # in INR
    land_type = db.Column(db.String(50), nullable=True)           # Agricultural, Non-Agricultural, Patta, etc.
    water_source = db.Column(db.String(50), nullable=True)
    agricultural_investment_score = db.Column(db.Integer, nullable=True)  # 0-100

    # Estimated Intelligence & Metrics
    est_monthly_rent = db.Column(db.Float, nullable=False, default=0.0)  # in INR
    gross_rental_yield = db.Column(db.Float, nullable=False, default=0.0)
    investment_score = db.Column(db.Integer, nullable=False, default=50, index=True)  # 0-100
    score_breakdown_json = db.Column(db.Text, nullable=True)  # JSON details
    growth_score = db.Column(db.Integer, default=85)
    location_score = db.Column(db.Integer, default=88)
    value_score = db.Column(db.Integer, default=87)

    # Verification & Metadata
    is_verified = db.Column(db.Boolean, default=False, index=True)
    is_featured = db.Column(db.Boolean, default=False, index=True)
    is_synthetic = db.Column(db.Boolean, default=True)
    data_source = db.Column(db.String(100), default='EstateIQ Seed Engine v2.0')
    verification_status = db.Column(db.String(30), default='Pending')  # Pending, Verified, Rejected
    rejection_reason = db.Column(db.Text, nullable=True)

    # Owner / Agent association
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    contact_person = db.Column(db.String(100), nullable=True)
    land_owner_name = db.Column(db.String(100), nullable=True)
    contact_phone = db.Column(db.String(20), nullable=True)
    contact_email = db.Column(db.String(120), nullable=True)

    # Amenities (comma separated string)
    amenities = db.Column(db.Text, nullable=True)

    # Stats
    views_count = db.Column(db.Integer, default=0)
    saved_count = db.Column(db.Integer, default=0)
    leads_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    images = db.relationship('PropertyImage', backref='property', lazy=True, cascade='all, delete-orphan')
    leads = db.relationship('Lead', backref='property', lazy=True, cascade='all, delete-orphan')

    @property
    def is_agricultural(self):
        return self.property_type in [
            'Agricultural Land', 'Farm Land', 'Orchard',
            'Plantation Land', 'Farm House Land', 'Agricultural Plot'
        ]

    def main_image(self):
        if self.images and len(self.images) > 0:
            return self.images[0].image_url
        if self.is_agricultural:
            return 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80'
        return 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'

    def formatted_price(self):
        return format_currency(self.price)

    def formatted_rent(self):
        return f"{format_currency(self.est_monthly_rent)}/mo"

    def formatted_area(self):
        if self.is_agricultural and self.land_area_acres:
            parts = []
            if self.land_area_acres:
                parts.append(f"{self.land_area_acres:.2f} Acres")
            if self.land_area_guntas:
                parts.append(f"{self.land_area_guntas:.0f} Guntas")
            return " / ".join(parts) if parts else f"{format_number(self.area_sqft)} sq.ft"
        return f"{format_number(self.area_sqft)} sq.ft"

    def full_location_address(self):
        loc = self.location_rel
        if not loc:
            return self.address or 'Telangana'
        return loc.full_location_string()


class PropertyImage(db.Model):
    __tablename__ = 'property_images'

    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    image_url = db.Column(db.String(255), nullable=False)
    caption = db.Column(db.String(100), nullable=True)
    is_primary = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
