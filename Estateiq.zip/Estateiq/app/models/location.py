from datetime import datetime
from app.extensions import db

class Location(db.Model):
    __tablename__ = 'locations'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)
    
    # Hierarchy
    state = db.Column(db.String(50), default='Telangana', nullable=False, index=True)
    district = db.Column(db.String(100), nullable=False, default='Hyderabad', index=True)
    mandal = db.Column(db.String(100), nullable=True, index=True)
    town_city = db.Column(db.String(100), nullable=True)
    locality_village = db.Column(db.String(100), nullable=True)
    pincode = db.Column(db.String(10), nullable=True)
    location_type = db.Column(db.String(30), default='locality') # district, mandal, town, locality, village
    
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    
    # Market statistics (aggregated)
    avg_price_per_sqft = db.Column(db.Float, nullable=False, default=0.0)
    avg_price_per_acre = db.Column(db.Float, nullable=False, default=0.0) # in INR e.g. 15000000 (1.5 Cr)
    avg_monthly_rent = db.Column(db.Float, nullable=False, default=0.0)
    avg_rental_yield = db.Column(db.Float, nullable=False, default=0.0)
    annual_appreciation_rate = db.Column(db.Float, nullable=False, default=7.5) # Percentage
    rental_demand_score = db.Column(db.Integer, default=80) # 0-100
    location_quality_score = db.Column(db.Integer, default=85) # 0-100
    growth_potential_score = db.Column(db.Integer, default=85) # 0-100
    total_inventory = db.Column(db.Integer, default=0)
    
    description = db.Column(db.Text, nullable=True)
    highlights = db.Column(db.Text, nullable=True)  # JSON or comma separated
    image_url = db.Column(db.String(255), nullable=True)
    
    data_source = db.Column(db.String(100), default='EstateIQ Telangana Dataset v2.0')
    is_synthetic = db.Column(db.Boolean, default=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    properties = db.relationship('Property', backref='location_rel', lazy=True)
    price_histories = db.relationship('PriceHistory', backref='location_rel', lazy=True, cascade='all, delete-orphan')

    def full_location_string(self):
        parts = []
        if self.locality_village or self.name:
            parts.append(self.locality_village or self.name)
        if self.mandal:
            parts.append(f"{self.mandal} Mandal")
        if self.district:
            parts.append(f"{self.district} District")
        parts.append(self.state or "Telangana")
        return ", ".join(parts)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'state': self.state,
            'district': self.district,
            'mandal': self.mandal,
            'town_city': self.town_city,
            'locality_village': self.locality_village,
            'pincode': self.pincode,
            'full_location': self.full_location_string(),
            'avg_price_per_sqft': self.avg_price_per_sqft,
            'avg_price_per_acre': self.avg_price_per_acre,
            'avg_monthly_rent': self.avg_monthly_rent,
            'avg_rental_yield': self.avg_rental_yield,
            'annual_appreciation_rate': self.annual_appreciation_rate,
            'rental_demand_score': self.rental_demand_score,
            'growth_potential_score': self.growth_potential_score,
            'latitude': self.latitude,
            'longitude': self.longitude
        }

class PriceHistory(db.Model):
    __tablename__ = 'price_history'

    id = db.Column(db.Integer, primary_key=True)
    location_id = db.Column(db.Integer, db.ForeignKey('locations.id'), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    quarter = db.Column(db.Integer, nullable=True)
    avg_price_per_sqft = db.Column(db.Float, nullable=False)
    avg_price_per_acre = db.Column(db.Float, nullable=True, default=0.0)
    avg_monthly_rent = db.Column(db.Float, nullable=False)
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow)
