from datetime import datetime
from app.extensions import db

class Lead(db.Model):
    __tablename__ = 'leads'

    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True) # Optional if registered
    
    sender_name = db.Column(db.String(100), nullable=False)
    sender_email = db.Column(db.String(120), nullable=False)
    sender_phone = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=True)
    preferred_contact_time = db.Column(db.String(50), default='Anytime')
    
    status = db.Column(db.String(30), default='New')  # New, Contacted, Qualified, Closed
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
