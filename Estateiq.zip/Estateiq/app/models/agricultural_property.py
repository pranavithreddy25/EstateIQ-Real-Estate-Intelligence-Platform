from datetime import datetime
from app.extensions import db

AGRICULTURAL_PROPERTY_TYPES = [
    'Agricultural Land',
    'Farm Land',
    'Orchard',
    'Plantation Land',
    'Farm House Land',
    'Agricultural Plot'
]

IRRIGATION_SOURCES = ['Borewell', 'Canal', 'Rainfed', 'River', 'Tank', 'Drip Irrigation']
ROAD_ACCESS_TYPES = ['BT Road', 'Tar Road', 'Mud Road', 'Panchayat Road', 'Highway Facing']
SOIL_TYPES = ['Red Soil', 'Black Cotton Soil', 'Sandy Loam', 'Clay Soil', 'Alluvial Soil']
LAND_TYPES = ['Agricultural Patta', 'Non-Agricultural (NA)', 'Farm Land Title', 'Assigned Land']


class AgriculturalDetails(db.Model):
    __tablename__ = 'agricultural_details'

    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id', ondelete='CASCADE'), unique=True, nullable=False)

    # Land Measurements
    acres = db.Column(db.Float, nullable=False, default=0.0)
    guntas = db.Column(db.Float, nullable=False, default=0.0)
    cents = db.Column(db.Float, nullable=True, default=0.0)
    total_sqft = db.Column(db.Float, nullable=False, default=0.0)

    # Agricultural Attributes
    survey_number = db.Column(db.String(50), nullable=True)
    land_type = db.Column(db.String(50), default='Agricultural Patta')
    irrigation_source = db.Column(db.String(50), default='Borewell')
    road_access = db.Column(db.String(50), default='BT Road')
    soil_type = db.Column(db.String(50), default='Red Soil')
    crop_type = db.Column(db.String(100), nullable=True)

    # Infrastructure & Amenities
    electricity_available = db.Column(db.Boolean, default=True)
    fencing_available = db.Column(db.Boolean, default=False)
    farmhouse_available = db.Column(db.Boolean, default=False)
    water_source = db.Column(db.String(100), nullable=True)

    # Economic Returns
    expected_annual_crop_income = db.Column(db.Float, default=0.0)  # INR
    agricultural_investment_score = db.Column(db.Integer, default=75)  # 0-100

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationship
    property = db.relationship('Property', backref=db.backref('agricultural_details', uselist=False, cascade='all, delete-orphan'))

    def to_dict(self):
        return {
            'id': self.id,
            'property_id': self.property_id,
            'acres': self.acres,
            'guntas': self.guntas,
            'cents': self.cents,
            'total_sqft': self.total_sqft,
            'survey_number': self.survey_number,
            'land_type': self.land_type,
            'irrigation_source': self.irrigation_source,
            'road_access': self.road_access,
            'soil_type': self.soil_type,
            'crop_type': self.crop_type,
            'electricity_available': self.electricity_available,
            'fencing_available': self.fencing_available,
            'farmhouse_available': self.farmhouse_available,
            'expected_annual_crop_income': self.expected_annual_crop_income,
            'agricultural_investment_score': self.agricultural_investment_score,
        }
