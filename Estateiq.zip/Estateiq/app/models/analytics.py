from datetime import datetime
from app.extensions import db

class SavedProperty(db.Model):
    __tablename__ = 'saved_properties'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    property_id = db.Column(db.Integer, db.ForeignKey('properties.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    property_rel = db.relationship('Property', backref='saved_by_users', lazy=True)

class SavedSearch(db.Model):
    __tablename__ = 'saved_searches'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    search_name = db.Column(db.String(100), nullable=False)
    criteria_json = db.Column(db.Text, nullable=False)  # JSON string of filters
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class InvestmentAnalysis(db.Model):
    __tablename__ = 'investment_analyses'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    title = db.Column(db.String(150), nullable=False)
    budget = db.Column(db.Float, nullable=False)
    purpose = db.Column(db.String(50), default='investment')
    city = db.Column(db.String(100), default='Hyderabad')
    assumptions_json = db.Column(db.Text, nullable=False) # JSON inputs
    results_json = db.Column(db.Text, nullable=False)     # JSON calculated outputs
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
